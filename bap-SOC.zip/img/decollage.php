<div id="svg-decollagefusee">

<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 1311.36 785.03">
    <defs>
        <radialGradient id="radial-gradient" cx="600.62" cy="384" r="649.61" gradientTransform="translate(-328.84 15.36) scale(1.64 0.96)" gradientUnits="userSpaceOnUse">
            <stop offset="0" stop-color="#fff" stop-opacity="0"/>
            <stop offset="0.65" stop-color="#b3b3b2" stop-opacity="0.1"/>
            <stop offset="1" stop-color="#1d1e1c" stop-opacity="0.3"/>
        </radialGradient>
        <radialGradient id="radial-gradient-2" cx="-2721.16" cy="-753.82" fx="-2743.04914574901" fy="-734.7256387521733" r="29.04" gradientTransform="translate(-2331.35 -531.74) rotate(-180)" gradientUnits="userSpaceOnUse">
            <stop offset="0" stop-color="#fff" stop-opacity="0"/>
            <stop offset="0.36" stop-color="#fff" stop-opacity="0.01"/>
            <stop offset="0.49" stop-color="#fff" stop-opacity="0.03"/>
            <stop offset="0.59" stop-color="#fff" stop-opacity="0.08"/>
            <stop offset="0.67" stop-color="#fff" stop-opacity="0.15"/>
            <stop offset="0.74" stop-color="#fff" stop-opacity="0.24"/>
            <stop offset="0.8" stop-color="#fff" stop-opacity="0.34"/>
            <stop offset="0.85" stop-color="#fff" stop-opacity="0.47"/>
            <stop offset="0.91" stop-color="#fff" stop-opacity="0.62"/>
            <stop offset="0.95" stop-color="#fff" stop-opacity="0.79"/>
            <stop offset="0.99" stop-color="#fff" stop-opacity="0.98"/>
            <stop offset="1" stop-color="#fff"/>
        </radialGradient>
        <clipPath id="clip-path">
            <rect x="0.05" width="1311.31" height="768" style="fill: none"/>
        </clipPath>
        <linearGradient id="linear-gradient" x1="471.14" y1="477.19" x2="510.83" y2="477.19" gradientTransform="matrix(0.87, 0.44, -0.52, 1.02, 471.56, -569.35)" gradientUnits="userSpaceOnUse">
            <stop offset="0.09" stop-color="#b93355"/>
            <stop offset="0.59" stop-color="#a8182d"/>
            <stop offset="0.99" stop-color="#7f1623"/>
        </linearGradient>
        <linearGradient id="linear-gradient-2" x1="582.55" y1="479.15" x2="549.58" y2="465.62" xlink:href="#linear-gradient"/>
        <linearGradient id="linear-gradient-3" x1="765.34" y1="313.5" x2="804.39" y2="313.5" gradientTransform="matrix(1.09, -0.57, 0.17, 1.22, -168.61, 115.03)" xlink:href="#linear-gradient"/>
        <linearGradient id="linear-gradient-4" x1="535.99" y1="478.8" x2="519.47" y2="478.8" xlink:href="#linear-gradient"/>
    </defs>
    <title>FUSEE_CLAVIER</title>
    <g style="isolation: isolate">
        <g id="Background">
            <rect x="0.05" width="1311.31" height="768" style="fill: #8cc2be"/>
            <g>
                <circle cx="542.35" cy="513.16" r="19.79" transform="translate(-84.78 918.35) rotate(-76.28)" style="fill: #f1f1f1"/>
                <circle cx="539.03" cy="474.25" r="17.22" transform="translate(-49.51 885.45) rotate(-76.28)" style="fill: #f1f1f1"/>
                <circle cx="533.33" cy="438.13" r="14.11" transform="translate(-18.77 852.36) rotate(-76.28)" style="fill: #f1f1f1"/>
                <circle cx="529.97" cy="411.12" r="9.62" transform="translate(4.9 828.47) rotate(-76.28)" style="fill: #f1f1f1"/>
                <circle cx="520.95" cy="386.5" r="6.27" transform="translate(21.93 800.93) rotate(-76.28)" style="fill: #f1f1f1"/>
                <circle cx="315.48" cy="568.61" r="12.31" style="fill: #f1f1f1"/>
                <circle cx="305.4" cy="544.51" r="10.08" style="fill: #f1f1f1"/>
                <circle cx="298.49" cy="526.33" r="6.87" style="fill: #f1f1f1"/>
                <circle cx="288.06" cy="510.77" r="4.48" style="fill: #f1f1f1"/>
                <circle cx="372.25" cy="538.12" r="27.41" transform="translate(-214.42 827.88) rotate(-81.61)" style="fill: #e5e5e5"/>
                <circle cx="362.68" cy="484.89" r="23.86" transform="translate(-169.93 772.96) rotate(-81.61)" style="fill: #e5e5e5"/>
                <circle cx="350.17" cy="435.83" r="19.54" transform="translate(-132.09 718.65) rotate(-81.61)" style="fill: #e5e5e5"/>
                <circle cx="342.07" cy="399" r="13.32" transform="translate(-102.57 679.2) rotate(-81.61)" style="fill: #e5e5e5"/>
                <circle cx="326.46" cy="366.22" r="8.68" transform="translate(-83.46 635.76) rotate(-81.61)" style="fill: #e5e5e5"/>
                <circle cx="486.37" cy="519.07" r="34.06" transform="translate(-98.11 924.5) rotate(-81.61)" style="fill: #e5e5e5"/>
                <circle cx="474.48" cy="447.91" r="29.65" transform="translate(-37.86 851.97) rotate(-81.61)" style="fill: #e5e5e5"/>
                <circle cx="458.92" cy="386.92" r="24.29" transform="translate(9.17 784.47) rotate(-81.61)" style="fill: #e5e5e5"/>
                <circle cx="448.85" cy="341.15" r="16.55" transform="translate(45.87 735.43) rotate(-81.61)" style="fill: #e5e5e5"/>
                <circle cx="429.45" cy="300.4" r="10.78" transform="translate(69.62 681.43) rotate(-81.61)" style="fill: #e5e5e5"/>
                <circle cx="431.61" cy="542.02" r="12.43" transform="translate(-206.21 812.69) rotate(-74.46)" style="fill: #f1f1f1"/>
                <circle cx="430.31" cy="517.53" r="10.82" transform="translate(-183.57 793.49) rotate(-74.46)" style="fill: #f1f1f1"/>
                <circle cx="427.44" cy="494.74" r="8.86" transform="translate(-163.71 774.04) rotate(-74.46)" style="fill: #f1f1f1"/>
                <circle cx="425.87" cy="477.7" r="6.04" transform="translate(-148.46 760.04) rotate(-74.46)" style="fill: #f1f1f1"/>
                <circle cx="420.7" cy="462.07" r="3.94" transform="matrix(0.27, -0.96, 0.96, 0.27, -137.16, 743.65)" style="fill: #f1f1f1"/>
            </g>
            <g>
                <circle cx="668.69" cy="531.86" r="14.14" style="fill: #f1f1f1"/>
                <circle cx="677.58" cy="505.41" r="12.31" style="fill: #f1f1f1"/>
                <circle cx="687.66" cy="481.31" r="10.08" style="fill: #f1f1f1"/>
                <circle cx="694.57" cy="463.12" r="6.87" style="fill: #f1f1f1"/>
                <circle cx="705" cy="447.57" r="4.48" style="fill: #f1f1f1"/>
                <circle cx="843.74" cy="519.38" r="12.31" style="fill: #f1f1f1"/>
                <circle cx="853.82" cy="495.28" r="10.08" style="fill: #f1f1f1"/>
                <circle cx="860.73" cy="477.09" r="6.87" style="fill: #f1f1f1"/>
                <circle cx="871.16" cy="461.53" r="4.48" style="fill: #f1f1f1"/>
                <circle cx="803.47" cy="499.93" r="24.12" style="fill: #e5e5e5"/>
                <circle cx="818.64" cy="454.81" r="21" style="fill: #e5e5e5"/>
                <circle cx="835.84" cy="413.69" r="17.2" style="fill: #e5e5e5"/>
                <circle cx="847.63" cy="382.66" r="11.72" style="fill: #e5e5e5"/>
                <circle cx="865.43" cy="356.12" r="7.64" style="fill: #e5e5e5"/>
                <circle cx="743.67" cy="517.33" r="24.12" transform="translate(-111.39 218.07) rotate(-15.53)" style="fill: #e5e5e5"/>
                <circle cx="746.2" cy="469.79" r="21" transform="translate(-98.56 217.02) rotate(-15.54)" style="fill: #e5e5e5"/>
                <circle cx="751.76" cy="425.57" r="17.2" transform="translate(-86.52 216.89) rotate(-15.54)" style="fill: #e5e5e5"/>
                <circle cx="754.8" cy="392.52" r="11.72" transform="translate(-77.55 216.51) rotate(-15.54)" style="fill: #e5e5e5"/>
                <circle cx="764.84" cy="362.18" r="7.64" transform="translate(-69.06 218.09) rotate(-15.54)" style="fill: #e5e5e5"/>
                <circle cx="834.85" cy="545.82" r="14.14" style="fill: #f1f1f1"/>
            </g>
			
			<g id="Trainees">
            <path d="M621.27,173c-1.57,4-3.14,8-4.62,12s-3,8-4.45,12l-4.32,12.07c-1.38,4-2.82,8.06-4.14,12.12q-8.19,24.25-15.38,48.76T575.17,319.3q-6.07,24.75-10.71,49.8c-1.66,8.32-3,16.71-4.36,25.07-1.22,8.39-2.54,16.77-3.51,25.2-1.18,8.4-1.86,16.85-2.79,25.29l-1,12.68c-0.16,2.11-.37,4.23-0.49,6.35L552,470C551,487,550.87,504,551.18,521l0.38,12.77c0.17,4.26.57,8.5,0.78,12.77l0.37,6.4c0.15,2.13.41,4.25,0.6,6.38,0.37,4.26.79,8.52,1.12,12.81-1-4.16-2-8.35-3-12.53-0.46-2.1-1-4.19-1.38-6.3L549,547l-1.12-6.36c-0.33-2.12-.77-4.24-1-6.38l-1.66-12.81a443.33,443.33,0,0,1-2.8-51.64V463.3c0-2.16.12-4.31,0.17-6.47,0.15-4.31.29-8.63,0.48-12.94,0.56-8.61,1.08-17.24,2-25.82,0.75-8.6,2-17.14,3.09-25.71,1.37-8.52,2.64-17.06,4.29-25.52,0.81-4.24,1.58-8.48,2.52-12.69s1.75-8.44,2.73-12.64l3-12.57c1-4.19,2.15-8.35,3.25-12.51q6.75-25,15.29-49.34t18.94-48c3.51-7.85,7.08-15.66,10.93-23.34S616.89,180.44,621.27,173Z" style="fill: #f1f1f1"/>
            <path d="M643.16,222.1c-1.16,3.88-2.33,7.75-3.41,11.64s-2.23,7.76-3.29,11.66c-2.12,7.79-4.28,15.55-6.21,23.37q-6,23.4-11.21,46.94t-9.45,47.22c-2.85,15.79-5.43,31.61-7.52,47.5l-0.83,6-0.72,6c-0.46,4-1,7.95-1.41,11.93l-1.27,11.95c-0.42,4-.68,8-1.07,12l-0.54,6-0.41,6-0.83,12c-0.35,8-.89,16-1,24a804.08,804.08,0,0,0,2.83,96.45,444.61,444.61,0,0,1-12.47-96.47c-0.09-4.07-.26-8.14-0.2-12.2l0.08-12.21c0.07-4.07.23-8.13,0.38-12.2l0.23-6.1,0.37-6.09c0.25-4.06.48-8.13,0.83-12.18L587.06,433c0.36-4.05.9-8.08,1.34-12.13l0.7-6.06,0.82-6c0.59-4,1.1-8.06,1.75-12.07l1.94-12c1.47-8,2.87-16,4.58-24q5-23.87,11.52-47.34T624.53,267c2.79-7.62,5.64-15.21,8.73-22.7S639.56,229.36,643.16,222.1Z" style="fill: #e5e5e5"/>
            <path d="M702.56,214.37c-1.31,4-2.64,8-3.86,12.05s-2.52,8-3.72,12.08l-3.6,12.1c-1.16,4-2.34,8.08-3.43,12.14q-6.79,24.28-12.7,48.73t-10.76,49.09c-3.26,16.42-6.18,32.9-8.59,49.45s-4.6,33.13-6.13,49.77L649.15,466c-0.2,2.08-.32,4.17-0.49,6.25l-1,12.5L647,497.29c-0.31,4.17-.39,8.35-0.54,12.53a764.38,764.38,0,0,0,2.94,100.62,448.45,448.45,0,0,1-12.58-100.7c-0.26-8.49,0-17,.08-25.48,0.14-4.24.33-8.48,0.53-12.73,0.11-2.12.18-4.24,0.32-6.36l0.45-6.35,0.47-6.35c0.16-2.12.31-4.24,0.54-6.35l1.27-12.67c0.45-4.22,1-8.42,1.57-12.64l0.81-6.32,0.94-6.3c0.67-4.19,1.24-8.4,2-12.57l2.2-12.54c1.66-8.32,3.24-16.65,5.16-24.92Q658.72,333.35,666,309t16.29-48.11c3.05-7.89,6.17-15.76,9.54-23.52S698.66,221.88,702.56,214.37Z" style="fill: #f1f1f1"/>
            </g>
			<g id="nuages">
			<path d="M968.44,683.37c12-4.69,20.35-15.38,20.35-27.83,0-16.77-15.19-30.36-33.94-30.36a36.13,36.13,0,0,0-22.7,7.8,36.7,36.7,0,0,0-12.92-10.24,28.63,28.63,0,0,0,1.68-9.66c0-17.51-15.86-31.7-35.43-31.7-0.89,0-1.77,0-2.65.1a58.46,58.46,0,0,0,.39-6.74c0-35.81-32.45-64.84-72.47-64.84A77.24,77.24,0,0,0,762.92,526a47.34,47.34,0,0,0-29.28-9.87c-18.13,0-33.71,9.73-40.61,23.66A47.23,47.23,0,0,0,662.51,529,49,49,0,0,0,647,531.48c0-.83.07-1.67,0.07-2.51,0-31.13-28.21-56.36-63-56.36S521,497.84,521,529a50.88,50.88,0,0,0,1.23,11.13,40.17,40.17,0,0,0-37.16.82c-8.17-21.21-30.66-36.46-57.14-36.46-31.94,0-58.07,22.17-60.28,50.24a104.38,104.38,0,0,0-42.39-8.86c-52.74,0-95.5,38.26-95.5,85.45a79.16,79.16,0,0,0,17.86,49.76,42.73,42.73,0,0,0-44,31.95c-2.1-.2-23.15-1.85-38,15-15,17-10.47,38-10,40h846.2c3.32-2.53,14.38-11.63,17.8-27.67,5.09-23.87-11.41-41.37-12.67-42.67C991.61,681.9,971.3,683.14,968.44,683.37Z" style="fill: #f1f1f1"/>
            </g>
			<path d="M1147.65,768c3.22-9.31,11.52-37.17,1-70-12.86-40.13-44.61-58.88-52-63,9.36-33.37-2.72-69-30-89-25.05-18.39-58.94-20.71-87-6-17.09,12.9-37,33-37.07,57.68q0,1.29.07,2.6a47.23,47.23,0,0,0-15.53-2.6A46,46,0,0,0,896.66,609c-6.89-14.48-22.45-24.59-40.55-24.59a46.08,46.08,0,0,0-29.24,10.26,75.21,75.21,0,0,0-47.76-16.78c-40,0-72.37,30.17-72.37,67.38a63.32,63.32,0,0,0,.39,7c-0.87-.06-1.75-0.1-2.65-0.1-19.54,0-35.38,14.75-35.38,32.94a30.84,30.84,0,0,0,1.68,10,36.92,36.92,0,0,0-12.9,10.64,35.2,35.2,0,0,0-22.67-8.1c-18.71,0-33.89,14.13-33.89,31.55,0,12.93,8.36,24,20.32,28.92A44.8,44.8,0,0,0,617.2,768h530.44Z" style="fill: #cbcbcb;opacity: 0.5"/>
            <path d="M69.65,768H563.59a65,65,0,0,0-34-12.29A84.33,84.33,0,0,0,547.46,704c0-49-42.69-88.79-95.36-88.79a100.76,100.76,0,0,0-42.33,9.21c-2.2-29.17-28.3-52.2-60.19-52.2-26.44,0-48.9,15.84-57.06,37.88a38.73,38.73,0,0,0-37.1-.85,54.88,54.88,0,0,0,1.23-11.57c0-30.18-24.51-55-56-58.21-19.33,2.71-69.83,12.65-101,54.53C77.77,623.4,74.1,656.86,69.92,695.05A347.51,347.51,0,0,0,69.65,768Z" style="fill: #cbcbcb;opacity: 0.5"/>
            <rect id="background_1" data-name="background 1" width="1311.31" height="768" style="mix-blend-mode: multiply;fill: url(#radial-gradient)"/>
        </g>
        <g id="Objects">
            <g>
                <path d="M466.5,315l14.09,41.45a4.69,4.69,0,0,0,5.92,3l54.61-17.88a4.69,4.69,0,0,0,3-5.92l-11.86-36.22-34.58,11.32-7.29-3.23Z" style="fill: #edbe66"/>
                <path d="M470.72,320.74L482.58,357a4.57,4.57,0,0,0,5.69,3.07l51.77-17a4.57,4.57,0,0,0,2.77-5.84L530.94,301Z" style="fill: #e4e4e4"/>
                <path d="M471.08,321.85l11.86,36.22a4.57,4.57,0,0,0,5.69,3.07l51.77-17a4.57,4.57,0,0,0,2.77-5.84l-11.86-36.22Z" style="fill: #f0f0f0"/>
                <rect x="472.92" y="316.92" width="5.37" height="5.47" transform="translate(-75.86 163.86) rotate(-18.13)" style="fill: #eb1c24"/>
                <path d="M471.45,323l11.86,36.22a4.57,4.57,0,0,0,5.69,3.07l51.77-17a4.57,4.57,0,0,0,2.77-5.84l-11.86-36.22Z" style="fill: #fff"/>
                <path d="M470.28,325l11.86,36.22a4.69,4.69,0,0,0,5.92,3l54.61-17.88a4.69,4.69,0,0,0,3-5.92L533.81,304.2Z" style="fill: #ffcd6e"/>
            </g>
            <g>
                <g>
                    <polygon points="442.61 386.78 413.76 374.02 387.95 432.36 430.56 451.21 450.28 406.62 442.61 386.78" style="fill: #fff"/>
                    <polygon points="442.6 386.77 436.51 400.53 450.27 406.62 442.6 386.77" style="fill: #e4e4e4"/>
                </g>
                <g>
                    <g>
                        <g>
                            <polygon points="425.15 391.51 396.31 378.75 370.5 437.09 413.1 455.94 432.82 411.36 425.15 391.51" style="fill: #fff"/>
                            <polygon points="425.14 391.51 419.06 405.27 432.82 411.35 425.14 391.51" style="fill: #e4e4e4"/>
                        </g>
                        <g>
                            <g>
                                <rect x="401.59" y="389.62" width="0.54" height="16.67" transform="translate(-124.64 604.47) rotate(-66.14)" style="fill: #cacaca"/>
                                <rect x="400.92" y="391.12" width="0.54" height="16.67" transform="translate(-126.41 604.77) rotate(-66.14)" style="fill: #cacaca"/>
                                <rect x="400.26" y="392.62" width="0.54" height="16.67" transform="translate(-128.2 605.01) rotate(-66.13)" style="fill: #cacaca"/>
                                <rect x="399.6" y="394.12" width="0.54" height="16.67" transform="translate(-129.97 605.29) rotate(-66.13)" style="fill: #cacaca"/>
                            </g>
                            <g>
                                <rect x="407.99" y="426.67" width="0.54" height="16.67" transform="translate(-154.72 632.38) rotate(-66.14)" style="fill: #cacaca"/>
                                <rect x="407.33" y="428.17" width="0.54" height="16.67" transform="translate(-156.49 632.67) rotate(-66.14)" style="fill: #cacaca"/>
                                <rect x="406.66" y="429.67" width="0.54" height="16.67" transform="translate(-158.26 632.95) rotate(-66.14)" style="fill: #cacaca"/>
                                <polygon points="413.78 443.13 398.54 436.39 398.75 435.89 414 442.64 413.78 443.13" style="fill: #cacaca"/>
                            </g>
                            <rect x="406.84" y="393.09" width="0.54" height="37.52" transform="translate(-134.23 617.56) rotate(-66.14)" style="fill: #cacaca"/>
                            <rect x="406.17" y="394.59" width="0.54" height="37.52" transform="translate(-136 617.83) rotate(-66.14)" style="fill: #cacaca"/>
                            <rect x="405.51" y="396.1" width="0.54" height="37.52" transform="translate(-137.78 618.1) rotate(-66.14)" style="fill: #cacaca"/>
                            <rect x="404.84" y="397.6" width="0.54" height="37.52" transform="translate(-139.54 618.41) rotate(-66.14)" style="fill: #cacaca"/>
                            <rect x="402.74" y="402.35" width="0.54" height="37.52" transform="translate(-145.14 619.3) rotate(-66.14)" style="fill: #cacaca"/>
                            <rect x="402.08" y="403.85" width="0.54" height="37.52" transform="translate(-146.91 619.58) rotate(-66.14)" style="fill: #cacaca"/>
                            <rect x="401.41" y="405.36" width="0.54" height="37.52" transform="translate(-148.67 619.89) rotate(-66.14)" style="fill: #cacaca"/>
                            <rect x="400.75" y="406.86" width="0.54" height="37.52" transform="translate(-150.45 620.16) rotate(-66.14)" style="fill: #cacaca"/>
                        </g>
                    </g>
                    <circle cx="383.08" cy="426.56" r="2.73" transform="translate(-161.99 604.34) rotate(-66.14)" style="fill: #eb1c24"/>
                    <circle cx="389.52" cy="429.41" r="2.73" transform="translate(-160.75 611.95) rotate(-66.14)" style="fill: #faec21"/>
                    <circle cx="395.97" cy="432.26" r="2.73" transform="translate(-159.52 619.54) rotate(-66.14)" style="fill: #8ac43f"/>
                </g>
            </g>
            <g id="enveloppe">
                <g>
                    <polygon points="353.86 306.12 299.32 299.19 296.33 335.25 350.87 342.19 353.86 306.12" style="fill: #e4e4e4"/>
                    <polygon points="296.33 335.25 326.58 302.78 350.87 342.19 296.33 335.25" style="fill: #f0f0f0"/>
                    <polygon points="353.86 306.12 324.19 331.64 299.32 299.19 353.86 306.12" style="fill: #fff"/>
                </g>
                <g>
                    <rect x="277.63" y="297.35" width="54.32" height="36.59" transform="translate(-95.77 136.52) rotate(-21.91)" style="fill: #e4e4e4"/>
                    <polygon points="286.41 342.76 298.01 298.8 336.81 322.49 286.41 342.76" style="fill: #f0f0f0"/>
                    <polygon points="323.16 288.54 308.93 325.96 272.76 308.81 323.16 288.54" style="fill: #fff"/>
                </g>
            </g>
            <g>
                <circle cx="389.78" cy="222.1" r="24.3" transform="translate(-42.88 340.67) rotate(-45)" style="fill: url(#radial-gradient-2)"/>
                <g>
                    <rect x="409.81" y="239.57" width="8.16" height="13.46" transform="translate(-52.93 364.82) rotate(-45)" style="fill: #f0f0f0"/>
                    <rect x="410.83" y="242.03" width="1.18" height="13.46" transform="translate(-55.47 363.5) rotate(-44.97)" style="fill: #e4e4e4"/>
                    <rect x="412.49" y="238.45" width="5.02" height="13.46" transform="translate(-51.83 365.25) rotate(-45)" style="fill: #e4e4e4"/>
                    <rect x="415.21" y="237.33" width="1.84" height="13.46" transform="translate(-50.7 365.72) rotate(-45)" style="fill: #cacaca"/>
                    <path d="M374.72,207.13a21.8,21.8,0,1,1,0,30.83,21.83,21.83,0,0,1,0-30.83m-4.8-4.8a28.6,28.6,0,1,0,40.44,0,28.59,28.59,0,0,0-40.44,0h0Z" style="fill: #5786a4"/>
                    <path d="M369.92,202.33a28.6,28.6,0,1,0,40.44,0A28.59,28.59,0,0,0,369.92,202.33Zm38.1,38.1a25.29,25.29,0,1,1,0-35.77A25.29,25.29,0,0,1,408,240.43Z" style="fill: #3a4f62"/>
                    <path d="M413.21,252.86l28.23,28.23a4.94,4.94,0,0,0,7,0l0.25-.25a4.94,4.94,0,0,0,0-7l-28.23-28.23Z" style="fill: #3a4f62"/>
                </g>
                <path d="M375.06,212.38s0.06-.13.2-0.37,0.33-.57.59-1l0.44-.68c0.2-.23.41-0.48,0.66-0.75s0.51-.55.79-0.84a10.93,10.93,0,0,1,1-.82c0.34-.28.71-0.55,1.09-0.84s0.82-.5,1.27-0.74l0.67-.38c0.23-.11.48-0.21,0.72-0.31,0.49-.2,1-0.39,1.53-0.56a16.73,16.73,0,0,1,3.36-.52c1.15-.11,2.32,0,3.47,0a26.37,26.37,0,0,1,3.41.46,23.19,23.19,0,0,1,3.18.89l1.45,0.62c0.23,0.1.47,0.19,0.69,0.31l0.65,0.36,1.23,0.69,1.08,0.75a11.73,11.73,0,0,1,1,.71l0.82,0.71,0.71,0.62,0.55,0.59,1,1.11-0.26.26-1.19-.88-0.62-.46-0.78-.47-0.88-.53c-0.3-.19-0.67-0.33-1-0.51l-1.1-.54-1.23-.45-0.64-.24c-0.22-.07-0.45-0.12-0.67-0.19l-1.38-.37a27.76,27.76,0,0,0-2.94-.41,23.57,23.57,0,0,0-3-.06,18.16,18.16,0,0,0-3,.49c-1,.19-1.87.57-2.77,0.78-0.44.16-.87,0.3-1.3,0.42-0.21.07-.43,0.11-0.64,0.18l-0.61.22c-0.4.15-.81,0.27-1.2,0.4s-0.74.31-1.1,0.45l-0.53.2a3.77,3.77,0,0,0-.5.2l-0.9.4-0.84.35-0.72.37c-0.44.22-.8,0.38-1,0.49l-0.38.16Z" style="fill: #fff;opacity: 0.5"/>
            </g>
            <g>
                <path d="M818.38,327.94a4.24,4.24,0,0,1-3.3,5l-59.52,12.28a4.24,4.24,0,0,1-5-3.3l-11.18-54.18a4.25,4.25,0,0,1,3.3-5l59.52-12.28a4.25,4.25,0,0,1,5,3.3Z" style="fill: #f1f1f1"/>
                <path d="M808.4,279.55l-1.19-5.79a4.25,4.25,0,0,0-5-3.3l-59.52,12.28a4.25,4.25,0,0,0-3.3,5l1.2,5.79Z" style="fill: #a32126"/>
                <g>
                    <rect x="749.88" y="289.4" width="59.64" height="44.85" transform="matrix(0.98, -0.2, 0.2, 0.98, -46.93, 164)" style="fill: none;stroke: #a47c52;stroke-miterlimit: 10;stroke-width: 0.530598px"/>
                    <rect x="747.19" y="297.14" width="8.52" height="8.52" transform="translate(-45.39 158) rotate(-11.65)" style="fill: #a35b5e;stroke: #a47c52;stroke-miterlimit: 10;stroke-width: 0.606044px"/>
                    <rect x="755.53" y="295.42" width="8.52" height="8.52" transform="translate(-44.89 159.77) rotate(-11.66)" style="fill: none;stroke: #a47c52;stroke-miterlimit: 10;stroke-width: 0.606044px"/>
                    <rect x="763.88" y="293.7" width="8.52" height="8.52" transform="translate(-44.36 161.34) rotate(-11.66)" style="fill: none;stroke: #a47c52;stroke-miterlimit: 10;stroke-width: 0.606044px"/>
                    <rect x="772.22" y="291.98" width="8.52" height="8.52" transform="translate(-43.84 163.01) rotate(-11.66)" style="fill: none;stroke: #a47c52;stroke-miterlimit: 10;stroke-width: 0.606044px"/>
                    <rect x="780.57" y="290.26" width="8.52" height="8.52" transform="translate(-43.32 164.66) rotate(-11.66)" style="fill: none;stroke: #a47c52;stroke-miterlimit: 10;stroke-width: 0.606044px"/>
                    <rect x="788.91" y="288.53" width="8.52" height="8.52" transform="translate(-42.81 166.35) rotate(-11.66)" style="fill: none;stroke: #a47c52;stroke-miterlimit: 10;stroke-width: 0.606044px"/>
                    <rect x="797.26" y="286.81" width="8.52" height="8.52" transform="translate(-42.28 167.98) rotate(-11.66)" style="fill: none;stroke: #a47c52;stroke-miterlimit: 10;stroke-width: 0.606044px"/>
                    <rect x="748.91" y="305.49" width="8.52" height="8.52" transform="translate(-47.05 158.56) rotate(-11.66)" style="fill: #a35b5e;stroke: #a47c52;stroke-miterlimit: 10;stroke-width: 0.606044px"/>
                    <rect x="757.25" y="303.77" width="8.52" height="8.52" transform="translate(-46.54 160.25) rotate(-11.66)" style="fill: none;stroke: #a47c52;stroke-miterlimit: 10;stroke-width: 0.606044px"/>
                    <rect x="765.6" y="302.04" width="8.52" height="8.52" transform="translate(-46.01 161.86) rotate(-11.66)" style="fill: none;stroke: #a47c52;stroke-miterlimit: 10;stroke-width: 0.606044px"/>
                    <rect x="773.94" y="300.32" width="8.52" height="8.52" transform="translate(-45.5 163.59) rotate(-11.66)" style="fill: none;stroke: #a47c52;stroke-miterlimit: 10;stroke-width: 0.606044px"/>
                    <rect x="782.29" y="298.6" width="8.52" height="8.52" transform="translate(-44.97 165.18) rotate(-11.66)" style="fill: none;stroke: #a47c52;stroke-miterlimit: 10;stroke-width: 0.606044px"/>
                    <rect x="790.63" y="296.88" width="8.52" height="8.52" transform="translate(-44.45 166.83) rotate(-11.66)" style="fill: none;stroke: #a47c52;stroke-miterlimit: 10;stroke-width: 0.606044px"/>
                    <rect x="798.98" y="295.16" width="8.52" height="8.52" transform="translate(-43.94 168.54) rotate(-11.66)" style="fill: none;stroke: #a47c52;stroke-miterlimit: 10;stroke-width: 0.606044px"/>
                    <rect x="750.63" y="313.83" width="8.52" height="8.52" transform="translate(-48.72 159.19) rotate(-11.66)" style="fill: #a35b5e;stroke: #a47c52;stroke-miterlimit: 10;stroke-width: 0.606044px"/>
                    <rect x="758.98" y="312.11" width="8.52" height="8.52" transform="translate(-48.18 160.74) rotate(-11.66)" style="fill: none;stroke: #a47c52;stroke-miterlimit: 10;stroke-width: 0.606044px"/>
                    <rect x="767.32" y="310.39" width="8.52" height="8.52" transform="translate(-47.66 162.38) rotate(-11.66)" style="fill: none;stroke: #a47c52;stroke-miterlimit: 10;stroke-width: 0.606044px"/>
                    <rect x="775.67" y="308.67" width="8.52" height="8.52" transform="translate(-47.15 164.07) rotate(-11.66)" style="fill: none;stroke: #a47c52;stroke-miterlimit: 10;stroke-width: 0.606044px"/>
                    <rect x="784.01" y="306.94" width="8.52" height="8.52" transform="translate(-46.62 165.7) rotate(-11.66)" style="fill: none;stroke: #a47c52;stroke-miterlimit: 10;stroke-width: 0.606044px"/>
                    <rect x="792.35" y="305.22" width="8.52" height="8.52" transform="translate(-46.11 167.4) rotate(-11.66)" style="fill: none;stroke: #a47c52;stroke-miterlimit: 10;stroke-width: 0.606044px"/>
                    <rect x="800.7" y="303.5" width="8.52" height="8.52" transform="translate(-45.58 168.99) rotate(-11.66)" style="fill: none;stroke: #a47c52;stroke-miterlimit: 10;stroke-width: 0.606044px"/>
                    <rect x="752.35" y="322.18" width="8.52" height="8.52" transform="translate(-50.37 159.7) rotate(-11.66)" style="fill: #a35b5e;stroke: #a47c52;stroke-miterlimit: 10;stroke-width: 0.606044px"/>
                    <rect x="760.7" y="320.45" width="8.52" height="8.52" transform="translate(-49.83 161.27) rotate(-11.66)" style="fill: none;stroke: #a47c52;stroke-miterlimit: 10;stroke-width: 0.606044px"/>
                    <rect x="769.04" y="318.73" width="8.52" height="8.52" transform="translate(-49.31 162.9) rotate(-11.66)" style="fill: none;stroke: #a47c52;stroke-miterlimit: 10;stroke-width: 0.606044px"/>
                    <rect x="777.39" y="317.01" width="8.52" height="8.52" transform="translate(-48.8 164.59) rotate(-11.66)" style="fill: none;stroke: #a47c52;stroke-miterlimit: 10;stroke-width: 0.606044px"/>
                    <rect x="785.73" y="315.29" width="8.52" height="8.52" transform="translate(-48.27 166.21) rotate(-11.66)" style="fill: none;stroke: #a47c52;stroke-miterlimit: 10;stroke-width: 0.606044px"/>
                    <rect x="794.08" y="313.57" width="8.52" height="8.52" transform="translate(-47.75 167.87) rotate(-11.66)" style="fill: none;stroke: #a47c52;stroke-miterlimit: 10;stroke-width: 0.606044px"/>
                    <rect x="802.42" y="311.85" width="8.52" height="8.52" transform="translate(-47.24 169.54) rotate(-11.66)" style="fill: none;stroke: #a47c52;stroke-miterlimit: 10;stroke-width: 0.606044px"/>
                    <rect x="754.07" y="330.52" width="8.52" height="8.52" transform="translate(-52.02 160.23) rotate(-11.66)" style="fill: #a35b5e;stroke: #a47c52;stroke-miterlimit: 10;stroke-width: 0.606044px"/>
                    <rect x="762.42" y="328.8" width="8.52" height="8.52" transform="translate(-51.47 161.71) rotate(-11.65)" style="fill: none;stroke: #a47c52;stroke-miterlimit: 10;stroke-width: 0.606044px"/>
                    <rect x="770.76" y="327.08" width="8.52" height="8.52" transform="translate(-50.98 163.52) rotate(-11.66)" style="fill: none;stroke: #a47c52;stroke-miterlimit: 10;stroke-width: 0.606044px"/>
                    <rect x="779.11" y="325.35" width="8.52" height="8.52" transform="translate(-50.44 165.08) rotate(-11.66)" style="fill: none;stroke: #a47c52;stroke-miterlimit: 10;stroke-width: 0.606044px"/>
                    <rect x="787.45" y="323.63" width="8.52" height="8.52" transform="translate(-49.93 166.76) rotate(-11.66)" style="fill: none;stroke: #a47c52;stroke-miterlimit: 10;stroke-width: 0.606044px"/>
                    <rect x="795.8" y="321.91" width="8.52" height="8.52" transform="translate(-49.4 168.37) rotate(-11.66)" style="fill: none;stroke: #a47c52;stroke-miterlimit: 10;stroke-width: 0.606044px"/>
                    <rect x="804.14" y="320.19" width="8.52" height="8.52" transform="translate(-48.89 170.08) rotate(-11.66)" style="fill: none;stroke: #a47c52;stroke-miterlimit: 10;stroke-width: 0.606044px"/>
                </g>
                <g>
                    <path d="M747.21,287.26a1.45,1.45,0,0,1-1.12,1.71h0a1.45,1.45,0,0,1-1.71-1.12l-1.85-8.95a1.45,1.45,0,0,1,1.12-1.71h0a1.45,1.45,0,0,1,1.71,1.12Z" style="fill: #3a4f62"/>
                    <path d="M743,277.55a1.44,1.44,0,0,0-.44,1.35l1.85,8.95a1.44,1.44,0,0,0,.94,1.07Z" style="fill: #81a4bb"/>
                    <path d="M754.14,285.83a1.45,1.45,0,0,1-1.12,1.71h0a1.44,1.44,0,0,1-1.71-1.12l-1.85-8.95a1.44,1.44,0,0,1,1.12-1.71h0a1.45,1.45,0,0,1,1.71,1.12Z" style="fill: #3a4f62"/>
                    <path d="M761.07,284.4a1.45,1.45,0,0,1-1.12,1.71h0a1.45,1.45,0,0,1-1.71-1.12L756.39,276a1.45,1.45,0,0,1,1.12-1.71h0a1.45,1.45,0,0,1,1.71,1.12Z" style="fill: #3a4f62"/>
                    <path d="M768,283a1.45,1.45,0,0,1-1.12,1.71h0a1.45,1.45,0,0,1-1.71-1.12l-1.85-8.95a1.45,1.45,0,0,1,1.12-1.71h0a1.45,1.45,0,0,1,1.71,1.12Z" style="fill: #3a4f62"/>
                    <path d="M774.92,281.54a1.44,1.44,0,0,1-1.12,1.71h0a1.44,1.44,0,0,1-1.71-1.12l-1.85-8.95a1.45,1.45,0,0,1,1.12-1.71h0a1.44,1.44,0,0,1,1.71,1.12Z" style="fill: #3a4f62"/>
                    <path d="M781.85,280.11a1.45,1.45,0,0,1-1.12,1.71h0A1.45,1.45,0,0,1,779,280.7l-1.84-8.95A1.45,1.45,0,0,1,778.3,270h0a1.45,1.45,0,0,1,1.71,1.12Z" style="fill: #3a4f62"/>
                    <path d="M788.78,278.68a1.45,1.45,0,0,1-1.12,1.71h0a1.45,1.45,0,0,1-1.71-1.12l-1.85-8.95a1.45,1.45,0,0,1,1.12-1.71h0a1.45,1.45,0,0,1,1.71,1.12Z" style="fill: #3a4f62"/>
                    <path d="M795.71,277.25a1.45,1.45,0,0,1-1.12,1.71h0a1.44,1.44,0,0,1-1.71-1.12L791,268.89a1.45,1.45,0,0,1,1.12-1.71h0a1.45,1.45,0,0,1,1.71,1.12Z" style="fill: #3a4f62"/>
                    <path d="M802.64,275.82a1.45,1.45,0,0,1-1.12,1.71h0a1.45,1.45,0,0,1-1.71-1.12L798,267.46a1.45,1.45,0,0,1,1.12-1.71h0a1.45,1.45,0,0,1,1.71,1.12Z" style="fill: #3a4f62"/>
                    <path d="M749.9,276.12a1.44,1.44,0,0,0-.44,1.35l1.85,8.95a1.44,1.44,0,0,0,.94,1.07Z" style="fill: #81a4bb"/>
                    <path d="M756.83,274.69a1.44,1.44,0,0,0-.44,1.35l1.85,8.95a1.44,1.44,0,0,0,.94,1.07Z" style="fill: #81a4bb"/>
                    <path d="M763.76,273.26a1.44,1.44,0,0,0-.44,1.35l1.85,8.95a1.44,1.44,0,0,0,.94,1.07Z" style="fill: #81a4bb"/>
                    <path d="M770.69,271.83a1.44,1.44,0,0,0-.44,1.35l1.85,8.95a1.44,1.44,0,0,0,.94,1.07Z" style="fill: #81a4bb"/>
                    <path d="M777.62,270.4a1.44,1.44,0,0,0-.44,1.35L779,280.7a1.44,1.44,0,0,0,.94,1.07Z" style="fill: #81a4bb"/>
                    <path d="M784.55,269a1.44,1.44,0,0,0-.44,1.35l1.85,8.95a1.44,1.44,0,0,0,.94,1.07Z" style="fill: #81a4bb"/>
                    <path d="M791.48,267.54a1.44,1.44,0,0,0-.44,1.35l1.85,8.95a1.44,1.44,0,0,0,.94,1.07Z" style="fill: #81a4bb"/>
                    <path d="M798.41,266.11a1.44,1.44,0,0,0-.44,1.35l1.85,8.95a1.44,1.44,0,0,0,.94,1.07Z" style="fill: #81a4bb"/>
                </g>
            </g>
            <g id="avion_ppapier">
                <polygon points="868.33 435.07 884.57 443.6 935.17 413.68 868.33 435.07" style="fill: #fff"/>
                <polygon points="884.57 443.6 884.57 462.09 935.17 413.68 884.57 443.6" style="fill: #cacaca"/>
                <polygon points="884.57 462.09 892.13 448.1 935.17 413.68 884.57 462.09" style="fill: #e4e4e4"/>
                <polygon points="892.13 448.1 909.87 459.84 935.17 413.68 892.13 448.1" style="fill: #fff"/>
            </g>
            <g id="horloge">
                <circle cx="901.75" cy="307.28" r="32.85" style="fill: #fff"/>
                <path d="M929.76,307.14a34,34,0,0,1-27.13,33,32.84,32.84,0,0,0,1.53-65.57A34,34,0,0,1,929.76,307.14Z" style="fill: #e4e4e4"/>
                <path d="M934.26,307.28a32.51,32.51,0,1,1-32.51-32.51,32.51,32.51,0,0,1,32.51,32.51m4.24,0A36.75,36.75,0,1,0,901.75,344a36.79,36.79,0,0,0,36.75-36.75h0Z" style="fill: #3a4f62"/>
                <g>
                    <path d="M874.54,307.67h1.25v-0.83h-1.25a1.38,1.38,0,0,0-2.63,0h-1.25v0.83h1.25A1.38,1.38,0,0,0,874.54,307.67Z" style="fill: #666"/>
                    <path d="M931.77,307.7h1.37v-0.83h-1.37a1.38,1.38,0,0,0-2.63,0H928v0.83h1.13A1.38,1.38,0,0,0,931.77,307.7Z" style="fill: #666"/>
                    <rect x="874.49" y="321.19" width="5.14" height="0.83" transform="translate(-43.32 481.49) rotate(-29.99)" style="fill: #666"/>
                    <rect x="884.98" y="331.69" width="5.14" height="0.83" transform="translate(156.18 934.71) rotate(-60)" style="fill: #666"/>
                    <path d="M902.3,338.52v-1.33a1.38,1.38,0,0,0,0-2.59v-1.21h-0.83v1.17a1.38,1.38,0,0,0,0,2.67v1.3h0.83Z" style="fill: #666"/>
                    <rect x="915.81" y="329.55" width="0.83" height="5.14" transform="translate(-43.19 503.29) rotate(-30.04)" style="fill: #666"/>
                    <rect x="926.31" y="319.06" width="0.83" height="5.14" transform="translate(185.05 963.63) rotate(-60.02)" style="fill: #666"/>
                    <rect x="924.17" y="292.53" width="5.14" height="0.83" transform="translate(-22.29 502.74) rotate(-30.01)" style="fill: #666"/>
                    <rect x="913.68" y="282.03" width="5.14" height="0.83" transform="translate(213.78 935) rotate(-60.02)" style="fill: #666"/>
                    <path d="M901.5,281.16h0.83v-1.22a1.38,1.38,0,0,0,0-2.59V276H901.5v1.29a1.38,1.38,0,0,0,0,2.67v1.17Z" style="fill: #666"/>
                    <rect x="887.16" y="279.86" width="0.83" height="5.13" transform="translate(-22.29 481.67) rotate(-30)" style="fill: #666"/>
                    <rect x="876.66" y="290.36" width="0.83" height="5.14" transform="translate(184.66 905.8) rotate(-59.98)" style="fill: #666"/>
                </g>
                <g>
                    <path d="M902.67,306.35a1.28,1.28,0,0,0-1.82,0l-12.08,12.07a1.28,1.28,0,0,0,1.82,1.82l12.07-12.07A1.28,1.28,0,0,0,902.67,306.35Zm-13.58,13.56a0.88,0.88,0,1,1,1.24,0A0.88,0.88,0,0,1,889.09,319.91Z" style="fill: #3a4f62"/>
                    <path d="M900.46,307.26a1.28,1.28,0,0,0,1.28,1.28h30.72a1.28,1.28,0,1,0,0-2.57H901.75A1.28,1.28,0,0,0,900.46,307.26Zm32.75,0a0.88,0.88,0,1,1-.88-0.88A0.88,0.88,0,0,1,933.21,307.26Z" style="fill: #3a4f62"/>
                    <circle cx="901.84" cy="307.27" r="1.38" style="fill: #2d688d"/>
                    <circle cx="902" cy="307.27" r="1.38" style="fill: #5786a4"/>
                </g>
            </g>
            <g>
                <path d="M230.8,432.55l1.14,2,1.38-.79a1.48,1.48,0,1,1,.49.86l-1.38.79,2.76,4.86,1.38-.79a1.48,1.48,0,1,1,.49.86l-1.38.79,2.76,4.86,1.38-.79a1.48,1.48,0,1,1,.49.86l-1.38.79,2.76,4.86,1.38-.79a1.48,1.48,0,1,1,.49.86l-1.38.79,2.76,4.86,1.38-.79a1.48,1.48,0,1,1,.49.86l-1.38.79,2.76,4.86,1.38-.79a1.48,1.48,0,1,1,.49.86l-1.38.79,2.76,4.86,1.38-.79a1.48,1.48,0,1,1,.49.86l-1.38.79,2.76,4.86,1.38-.79a1.48,1.48,0,1,1,.49.86l-1.38.79,2.76,4.86,1.38-.79a1.48,1.48,0,1,1,.49.86l-1.38.79,2.76,4.86,1.38-.79a1.48,1.48,0,1,1,.49.86l-1.38.79,1.14,2,41.14-23.36-32-56.35Z" style="fill: #fff"/>
                <g>
                    <path d="M223.52,452.16l1.14,2,1.38-.79a1.48,1.48,0,1,1,.49.86l-1.38.79,2.76,4.86,1.38-.79a1.48,1.48,0,1,1,.49.86l-1.38.79,2.76,4.86,1.38-.79a1.48,1.48,0,1,1,.49.86l-1.38.79,2.76,4.86,1.38-.79a1.48,1.48,0,1,1,.49.86l-1.38.79,2.76,4.86,1.38-.79a1.48,1.48,0,1,1,.49.86l-1.38.79,2.76,4.86,1.38-.79a1.48,1.48,0,1,1,.49.86l-1.38.79,2.76,4.86,1.38-.79a1.48,1.48,0,1,1,.49.86l-1.38.79,2.76,4.86,1.38-.79a1.48,1.48,0,1,1,.49.86l-1.38.79,2.76,4.86,1.38-.79a1.48,1.48,0,1,1,.49.86l-1.38.79,2.76,4.86,1.38-.79a1.48,1.48,0,1,1,.49.86l-1.38.79,1.14,2,41.14-23.36-32-56.35Z" style="fill: #fff"/>
                    <g>
                        <polygon points="260.86 503.22 295.68 483.45 295.81 483.69 260.99 503.46 260.86 503.22" style="fill: #cacaca"/>
                        <rect x="256.64" y="490.37" width="40.04" height="0.27" transform="translate(-206.1 200.55) rotate(-29.59)" style="fill: #cacaca"/>
                        <rect x="254.96" y="487.41" width="40.04" height="0.27" transform="translate(-204.86 199.34) rotate(-29.59)" style="fill: #cacaca"/>
                        <rect x="253.28" y="484.46" width="40.04" height="0.27" transform="translate(-203.62 198.12) rotate(-29.59)" style="fill: #cacaca"/>
                        <rect x="251.61" y="481.5" width="40.04" height="0.27" transform="translate(-202.38 196.91) rotate(-29.59)" style="fill: #cacaca"/>
                        <rect x="249.93" y="478.55" width="40.04" height="0.27" transform="translate(-201.14 195.7) rotate(-29.59)" style="fill: #cacaca"/>
                        <rect x="248.25" y="475.59" width="40.04" height="0.27" transform="translate(-199.9 194.48) rotate(-29.59)" style="fill: #cacaca"/>
                        <rect x="246.57" y="472.64" width="40.04" height="0.27" transform="translate(-198.66 193.27) rotate(-29.59)" style="fill: #cacaca"/>
                        <rect x="244.9" y="469.68" width="40.04" height="0.27" transform="translate(-197.42 192.05) rotate(-29.59)" style="fill: #cacaca"/>
                        <polygon points="245.76 476.63 280.59 456.86 280.72 457.1 245.9 476.87 245.76 476.63" style="fill: #cacaca"/>
                        <rect x="241.54" y="463.77" width="40.04" height="0.27" transform="translate(-194.94 189.63) rotate(-29.59)" style="fill: #cacaca"/>
                        <rect x="239.86" y="460.82" width="40.04" height="0.27" transform="translate(-193.7 188.42) rotate(-29.59)" style="fill: #cacaca"/>
                        <rect x="238.19" y="457.87" width="40.04" height="0.27" transform="translate(-192.46 187.2) rotate(-29.59)" style="fill: #cacaca"/>
                        <rect x="236.51" y="454.91" width="40.04" height="0.27" transform="translate(-191.22 185.99) rotate(-29.59)" style="fill: #cacaca"/>
                        <rect x="234.83" y="451.96" width="40.04" height="0.27" transform="translate(-189.98 184.78) rotate(-29.59)" style="fill: #cacaca"/>
                        <rect x="233.15" y="449" width="40.04" height="0.27" transform="translate(-188.74 183.56) rotate(-29.59)" style="fill: #cacaca"/>
                        <rect x="231.48" y="446.05" width="40.04" height="0.27" transform="translate(-187.51 182.36) rotate(-29.59)" style="fill: #cacaca"/>
                        <rect x="229.8" y="443.09" width="40.04" height="0.27" transform="translate(-186.26 181.14) rotate(-29.59)" style="fill: #cacaca"/>
                        <rect x="228.12" y="440.14" width="40.04" height="0.27" transform="translate(-185.02 179.92) rotate(-29.59)" style="fill: #cacaca"/>
                    </g>
                    <rect x="245.57" y="444.42" width="0.28" height="64.8" transform="translate(-203.2 183.21) rotate(-29.55)" style="fill: #2d688d"/>
                </g>
                <g>
                    <path d="M285.65,441.83a3.4,3.4,0,0,1-3.46,3.34h0a3.4,3.4,0,0,1-3.34-3.46l0.14-8.31a3.4,3.4,0,0,1,3.46-3.34h0a3.4,3.4,0,0,1,3.34,3.46Z" style="fill: #ff7bab"/>
                    <rect x="255.95" y="462.09" width="51.78" height="6.8" transform="translate(-188.48 739.2) rotate(-89)" style="fill: #333"/>
                    <rect x="257.28" y="463.45" width="51.78" height="4.14" transform="translate(-187.15 740.64) rotate(-89.01)" style="fill: #fbed21"/>
                    <rect x="258.61" y="464.8" width="51.78" height="1.48" transform="translate(-185.87 741.99) rotate(-89.01)" style="fill: #333"/>
                    <polygon points="284.8 491.44 281.25 499.98 278 491.32 284.8 491.44" style="fill: #f9d5b8"/>
                    <polygon points="280.41 497.74 281.25 499.98 282.17 497.77 280.41 497.74" style="fill: #4d4d4d"/>
                    <rect x="281.37" y="435.91" width="1.84" height="7.39" rx="0.39" ry="0.39" transform="translate(-162.1 714.32) rotate(-89.02)" style="fill: #cbcbcb"/>
                    <path d="M285.61,438.75l-1.45,0,0,1.84,1.45,0a0.39,0.39,0,0,0,.4-0.39l0-1.05A0.39,0.39,0,0,0,285.61,438.75Z" style="fill: #989898"/>
                </g>
            </g>
        </g>
        <g id="Main_clavier" data-name="Main clavier">
            <g id="Main_clavier-2" data-name="Main clavier">
                <g style="clip-path: url(#clip-path)">
                    <g>
                        <g>
                            <path d="M934.76,697c0,0.65-.9,1.18-2,1.17H378.66c-1.11,0-2-.53-2-1.18V546.26c0-.65.9-1.17,2-1.17H932.75c1.11,0,2,.53,2,1.18V697Z" style="fill: #b1b1b1"/>
                            <path d="M418.81,579.61c0,0.65-.9,1.18-2,1.18H386.62c-1.11,0-2-.53-2-1.18V570c0-.65.9-1.18,2-1.18H416.8c1.11,0,2,.53,2,1.18v9.64Z" style="fill: #cacaca"/>
                            <path d="M457.91,579.61c0,0.65-.9,1.18-2,1.18H425.72c-1.11,0-2-.53-2-1.18V570c0-.65.9-1.18,2-1.18H455.9c1.11,0,2,.53,2,1.18v9.64Z" style="fill: #cacaca"/>
                            <path d="M497,579.61c0,0.65-.9,1.18-2,1.18H464.82c-1.11,0-2-.53-2-1.18V570c0-.65.9-1.18,2-1.18H495c1.11,0,2,.53,2,1.18v9.64Z" style="fill: #cacaca"/>
                            <path d="M536.11,579.61c0,0.65-.9,1.18-2,1.18H503.92c-1.11,0-2-.53-2-1.18V570c0-.65.9-1.18,2-1.18H534.1c1.11,0,2,.53,2,1.18v9.64Z" style="fill: #cacaca"/>
                            <path d="M575.21,579.61c0,0.65-.9,1.17-2,1.17H543c-1.11,0-2-.53-2-1.17V570c0-.65.9-1.18,2-1.18H573.2c1.11,0,2,.53,2,1.18v9.64Z" style="fill: #cacaca"/>
                            <path d="M614.31,579.61c0,0.65-.9,1.18-2,1.18H582.11c-1.11,0-2-.53-2-1.17V570c0-.65.9-1.18,2-1.18H612.3c1.11,0,2,.53,2,1.18v9.63Z" style="fill: #cacaca"/>
                            <path d="M653.4,579.61c0,0.65-.9,1.18-2,1.18H621.22c-1.11,0-2-.53-2-1.18V570c0-.65.9-1.18,2-1.18H651.4c1.11,0,2,.53,2,1.18v9.63Z" style="fill: #cacaca"/>
                            <path d="M692.51,579.61c0,0.65-.9,1.18-2,1.18H660.32c-1.11,0-2-.53-2-1.18V570c0-.65.9-1.18,2-1.18H690.5c1.11,0,2,.53,2,1.18v9.63Z" style="fill: #cacaca"/>
                            <path d="M731.6,579.61c0,0.65-.9,1.18-2,1.18H699.42c-1.11,0-2-.53-2-1.18V570c0-.65.9-1.18,2-1.18h30.18c1.11,0,2,.53,2,1.18v9.63Z" style="fill: #cacaca"/>
                            <path d="M770.7,579.61c0,0.65-.9,1.18-2,1.18H738.52c-1.11,0-2-.53-2-1.18V570c0-.65.9-1.18,2-1.18H768.7c1.11,0,2,.53,2,1.18v9.63Z" style="fill: #cacaca"/>
                            <path d="M809.8,579.61c0,0.65-.9,1.18-2,1.18H777.61c-1.1,0-2-.53-2-1.18V570c0-.65.9-1.18,2-1.18h30.18c1.11,0,2,.53,2,1.18v9.63Z" style="fill: #cacaca"/>
                            <path d="M848.9,579.61c0,0.65-.9,1.18-2,1.18H816.71c-1.11,0-2-.53-2-1.18V570c0-.65.9-1.18,2-1.18h30.18c1.11,0,2,.53,2,1.18v9.63Z" style="fill: #cacaca"/>
                            <path d="M888,579.61c0,0.65-.9,1.18-2,1.18H855.81c-1.11,0-2-.53-2-1.18V570c0-.65.9-1.18,2-1.18H886c1.11,0,2,.53,2,1.17v9.64Z" style="fill: #cacaca"/>
                            <path d="M927.1,579.61c0,0.65-.9,1.18-2,1.18H894.91c-1.1,0-2-.53-2-1.18V570c0-.65.9-1.17,2-1.17h30.18c1.11,0,2,.53,2,1.17v9.64Z" style="fill: #cacaca"/>
                            <path d="M418.81,602.17c0,0.65-.9,1.17-2,1.17H386.62c-1.11,0-2-.52-2-1.17V584.49c0-.65.9-1.18,2-1.18H416.8c1.11,0,2,.53,2,1.18v17.68Z" style="fill: #cacaca"/>
                            <path d="M456.42,602.17c0,0.65-.9,1.17-2,1.17H424.24c-1.11,0-2-.52-2-1.17V584.49c0-.65.9-1.18,2-1.18h30.18c1.11,0,2,.53,2,1.18v17.68Z" style="fill: #cacaca"/>
                            <path d="M494,602.17c0,0.65-.9,1.18-2,1.18H461.85c-1.11,0-2-.52-2-1.18V584.49c0-.65.9-1.18,2-1.18H492c1.11,0,2,.53,2,1.18v17.68Z" style="fill: #cacaca"/>
                            <path d="M531.66,602.17c0,0.65-.9,1.18-2,1.18H499.46c-1.11,0-2-.52-2-1.18V584.49c0-.65.9-1.18,2-1.18h30.18c1.11,0,2,.53,2,1.18v17.68Z" style="fill: #cacaca"/>
                            <path d="M569.27,602.17c0,0.65-.9,1.18-2,1.18H537.08c-1.11,0-2-.53-2-1.18V584.49c0-.65.9-1.18,2-1.18h30.18c1.11,0,2,.53,2,1.18v17.68Z" style="fill: #cacaca"/>
                            <path d="M606.89,602.17c0,0.65-.9,1.18-2,1.18H574.7c-1.11,0-2-.53-2-1.18V584.49c0-.65.9-1.18,2-1.18h30.18c1.11,0,2,.53,2,1.18v17.68Z" style="fill: #cacaca"/>
                            <path d="M644.5,602.17c0,0.65-.9,1.18-2,1.18H612.31c-1.11,0-2-.53-2-1.18V584.49c0-.65.9-1.18,2-1.18H642.5c1.1,0,2,.53,2,1.18v17.68Z" style="fill: #cacaca"/>
                            <path d="M682.12,602.17c0,0.65-.9,1.18-2,1.18H649.93c-1.11,0-2-.53-2-1.18V584.49c0-.65.9-1.18,2-1.18h30.18c1.11,0,2,.53,2,1.18v17.68Z" style="fill: #cacaca"/>
                            <path d="M719.74,602.16c0,0.65-.9,1.18-2,1.18H687.55c-1.11,0-2-.53-2-1.18V584.49c0-.65.9-1.18,2-1.18h30.18c1.11,0,2,.53,2,1.18v17.67Z" style="fill: #cacaca"/>
                            <path d="M757.35,602.16c0,0.65-.9,1.18-2,1.18H725.16c-1.11,0-2-.53-2-1.18V584.49c0-.65.9-1.18,2-1.18h30.19c1.11,0,2,.53,2,1.18v17.68Z" style="fill: #cacaca"/>
                            <path d="M795,602.16c0,0.65-.9,1.18-2,1.18H762.78c-1.11,0-2-.53-2-1.18V584.49c0-.65.89-1.18,2-1.18H793c1.11,0,2,.53,2,1.18v17.68Z" style="fill: #cacaca"/>
                            <path d="M484.59,645c0,0.65-.9,1.18-2,1.18H452.4c-1.11,0-2-.53-2-1.18V627.32c0-.65.9-1.18,2-1.18h30.18c1.11,0,2,.53,2,1.18V645Z" style="fill: #cacaca"/>
                            <path d="M522.21,645c0,0.65-.9,1.18-2,1.18H490c-1.11,0-2-.53-2-1.18V627.32c0-.65.9-1.18,2-1.18H520.2c1.11,0,2,.53,2,1.18V645Z" style="fill: #cacaca"/>
                            <path d="M559.82,645c0,0.65-.9,1.18-2,1.18H527.63c-1.11,0-2-.53-2-1.18V627.32c0-.65.9-1.18,2-1.18h30.18c1.11,0,2,.53,2,1.18V645Z" style="fill: #cacaca"/>
                            <path d="M597.44,645c0,0.65-.9,1.18-2,1.18H565.25c-1.11,0-2-.53-2-1.18V627.32c0-.65.9-1.18,2-1.18h30.18c1.11,0,2,.53,2,1.18V645Z" style="fill: #cacaca"/>
                            <path d="M635.06,645c0,0.65-.9,1.18-2,1.18H602.87c-1.11,0-2-.53-2-1.18V627.31c0-.65.9-1.18,2-1.18H633c1.11,0,2,.53,2,1.18V645Z" style="fill: #cacaca"/>
                            <path d="M672.67,645c0,0.65-.9,1.18-2,1.18H640.48c-1.12,0-2-.53-2-1.18V627.31c0-.65.9-1.18,2-1.18h30.18c1.11,0,2,.53,2,1.18V645Z" style="fill: #cacaca"/>
                            <path d="M710.29,645c0,0.65-.9,1.18-2,1.18H678.1c-1.11,0-2-.53-2-1.18V627.31c0-.65.9-1.18,2-1.18h30.18c1.11,0,2,.53,2,1.18V645Z" style="fill: #cacaca"/>
                            <path d="M747.9,645c0,0.65-.9,1.18-2,1.18H715.71c-1.11,0-2-.53-2-1.18V627.31c0-.65.9-1.18,2-1.18h30.18c1.11,0,2,.53,2,1.18V645Z" style="fill: #cacaca"/>
                            <path d="M785.52,645c0,0.65-.9,1.18-2,1.18H753.33c-1.11,0-2-.53-2-1.18V627.31c0-.65.9-1.18,2-1.18h30.18c1.11,0,2,.53,2,1.18V645Z" style="fill: #cacaca"/>
                            <path d="M823.14,645c0,0.65-.9,1.18-2,1.18H790.95c-1.11,0-2-.53-2-1.18V627.31c0-.65.9-1.18,2-1.18h30.18c1.11,0,2,.53,2,1.18V645Z" style="fill: #cacaca"/>
                            <path d="M503.4,666.22c0,0.65-.9,1.18-2,1.18H471.21c-1.11,0-2-.52-2-1.18V648.55c0-.65.9-1.18,2-1.18h30.18c1.11,0,2,.53,2,1.18v17.68Z" style="fill: #cacaca"/>
                            <path d="M541,666.22c0,0.65-.9,1.18-2,1.18H508.82c-1.11,0-2-.52-2-1.18V648.55c0-.65.9-1.18,2-1.18H539c1.11,0,2,.52,2,1.18v17.68Z" style="fill: #cacaca"/>
                            <path d="M578.63,666.22c0,0.65-.9,1.18-2,1.18H546.44c-1.11,0-2-.52-2-1.18V648.55c0-.65.9-1.18,2-1.18h30.18c1.11,0,2,.52,2,1.18v17.68Z" style="fill: #cacaca"/>
                            <path d="M616.25,666.22c0,0.65-.9,1.18-2,1.18H584.06c-1.11,0-2-.52-2-1.18V648.55c0-.65.9-1.18,2-1.18h30.18c1.11,0,2,.52,2,1.18v17.68Z" style="fill: #cacaca"/>
                            <path d="M653.87,666.22c0,0.65-.9,1.18-2,1.18H621.67c-1.11,0-2-.52-2-1.18V648.55c0-.65.9-1.18,2-1.18h30.19c1.11,0,2,.53,2,1.18v17.68Z" style="fill: #cacaca"/>
                            <path d="M691.48,666.22c0,0.65-.9,1.18-2,1.18H659.29c-1.1,0-2-.52-2-1.18V648.55c0-.65.9-1.18,2-1.18h30.18c1.11,0,2,.53,2,1.18v17.68Z" style="fill: #cacaca"/>
                            <path d="M729.1,666.22c0,0.65-.9,1.18-2,1.18H696.91c-1.11,0-2-.52-2-1.18V648.55c0-.65.9-1.18,2-1.18h30.18c1.11,0,2,.53,2,1.18v17.68Z" style="fill: #cacaca"/>
                            <path d="M766.71,666.22c0,0.65-.9,1.18-2,1.18H734.53c-1.11,0-2-.52-2-1.18V648.55c0-.65.9-1.18,2-1.18H764.7c1.11,0,2,.53,2,1.18v17.68Z" style="fill: #cacaca"/>
                            <path d="M804.33,666.22c0,0.65-.9,1.18-2,1.18H772.14c-1.11,0-2-.52-2-1.18V648.55c0-.65.9-1.18,2-1.18h30.18c1.11,0,2,.53,2,1.18v17.68Z" style="fill: #cacaca"/>
                            <path d="M841.95,666.22c0,0.65-.9,1.18-2,1.18H809.76c-1.11,0-2-.53-2-1.18V648.55c0-.65.9-1.18,2-1.18h30.18c1.11,0,2,.53,2,1.18v17.68Z" style="fill: #cacaca"/>
                            <path d="M860.75,645c0,0.65-.9,1.18-2,1.18H828.56c-1.1,0-2-.53-2-1.18V627.31c0-.65.9-1.18,2-1.18h30.18c1.11,0,2,.53,2,1.18V645Z" style="fill: #cacaca"/>
                            <path d="M832.59,602.16c0,0.65-.9,1.18-2,1.18H800.4c-1.11,0-2-.53-2-1.18V584.49c0-.65.9-1.18,2-1.18h30.18c1.11,0,2,.53,2,1.18v17.68Z" style="fill: #cacaca"/>
                            <path d="M870.2,602.16c0,0.65-.9,1.18-2,1.18H838c-1.11,0-2-.53-2-1.18V584.49c0-.65.9-1.18,2-1.18H868.2c1.11,0,2,.53,2,1.18v17.68Z" style="fill: #cacaca"/>
                            <path d="M475,623.62c0,0.65-.9,1.18-2,1.18H442.82c-1.11,0-2-.52-2-1.18V605.94c0-.65.9-1.18,2-1.18H473c1.11,0,2,.53,2,1.18v17.68Z" style="fill: #cacaca"/>
                            <path d="M512.62,623.62c0,0.65-.9,1.18-2,1.18H480.43c-1.11,0-2-.52-2-1.18V605.94c0-.65.9-1.18,2-1.18h30.18c1.11,0,2,.53,2,1.18v17.68Z" style="fill: #cacaca"/>
                            <path d="M550.24,623.62c0,0.65-.9,1.18-2,1.18H518.05c-1.11,0-2-.52-2-1.18V605.94c0-.65.9-1.18,2-1.18h30.18c1.11,0,2,.53,2,1.18v17.68Z" style="fill: #cacaca"/>
                            <path d="M587.86,623.62c0,0.65-.9,1.18-2,1.18H555.67c-1.11,0-2-.52-2-1.18V605.94c0-.65.9-1.18,2-1.18h30.18c1.11,0,2,.53,2,1.18v17.68Z" style="fill: #cacaca"/>
                            <path d="M625.47,623.62c0,0.65-.9,1.18-2,1.18H593.28c-1.11,0-2-.52-2-1.18V605.94c0-.65.9-1.18,2-1.18h30.18c1.11,0,2,.53,2,1.18v17.68Z" style="fill: #cacaca"/>
                            <path d="M663.09,623.62c0,0.65-.9,1.18-2,1.18H630.9c-1.11,0-2-.53-2-1.18V605.94c0-.65.9-1.18,2-1.18h30.18c1.11,0,2,.53,2,1.18v17.68Z" style="fill: #cacaca"/>
                            <path d="M700.71,623.62c0,0.65-.9,1.18-2,1.18H668.51c-1.11,0-2-.53-2-1.18V605.94c0-.65.9-1.18,2-1.18H698.7c1.11,0,2,.53,2,1.18v17.68Z" style="fill: #cacaca"/>
                            <path d="M738.32,623.62c0,0.65-.9,1.18-2,1.18H706.13c-1.11,0-2-.53-2-1.18V605.94c0-.65.9-1.18,2-1.18h30.18c1.11,0,2,.53,2,1.18v17.68Z" style="fill: #cacaca"/>
                            <path d="M775.94,623.62c0,0.65-.9,1.18-2,1.18H743.75c-1.11,0-2-.53-2-1.18V605.94c0-.65.9-1.18,2-1.18h30.18c1.11,0,2,.53,2,1.17v17.68Z" style="fill: #cacaca"/>
                            <path d="M813.55,623.62c0,0.65-.9,1.18-2,1.18H781.37c-1.11,0-2-.53-2-1.18V605.94c0-.65.9-1.18,2-1.18h30.18c1.1,0,2,.53,2,1.18v17.67Z" style="fill: #cacaca"/>
                            <path d="M851.17,623.62c0,0.65-.9,1.18-2,1.18H819c-1.11,0-2-.53-2-1.18V605.94c0-.65.9-1.18,2-1.18h30.18c1.11,0,2,.53,2,1.18v17.67Z" style="fill: #cacaca"/>
                            <path d="M888.79,623.62c0,0.65-.9,1.18-2,1.18H856.6c-1.11,0-2-.53-2-1.18V605.94c0-.65.9-1.18,2-1.18h30.18c1.11,0,2,.53,2,1.18v17.67Z" style="fill: #cacaca"/>
                            <path d="M926.4,623.62c0,0.65-.9,1.18-2,1.18H894.21c-1.11,0-2-.53-2-1.18V605.94c0-.65.9-1.18,2-1.18h30.18c1.11,0,2,.53,2,1.18v17.67Z" style="fill: #cacaca"/>
                            <path d="M436.87,622.92c0,0.65-.9,1.18-2,1.18H386.62c-1.11,0-2-.52-2-1.18V606.65c0-.65.9-1.18,2-1.18h48.24c1.11,0,2,.53,2,1.18v16.26Z" style="fill: #cacaca"/>
                            <path d="M445.78,644.22c0,0.65-.9,1.18-2,1.18H386.62c-1.11,0-2-.53-2-1.18V628.09c0-.65.9-1.18,2-1.18h57.16c1.11,0,2,.53,2,1.18v16.13Z" style="fill: #cacaca"/>
                            <path d="M465,665.51c0,0.65-.9,1.17-2,1.17H386.62c-1.11,0-2-.52-2-1.17V649.26c0-.65.9-1.18,2-1.18H463c1.11,0,2,.53,2,1.18v16.26Z" style="fill: #cacaca"/>
                            <path d="M926.73,601.46c0,0.65-.9,1.18-2,1.18H876.48c-1.11,0-2-.53-2-1.18V585.19c0-.65.9-1.18,2-1.17h48.24c1.11,0,2,.53,2,1.18v16.27Z" style="fill: #cacaca"/>
                            <path d="M926.74,644.21c0,0.65-.9,1.18-2,1.18H867.57c-1.11,0-2-.53-2-1.18V628.09c0-.65.9-1.17,2-1.17h57.16c1.11,0,2,.53,2,1.18v16.13Z" style="fill: #cacaca"/>
                            <path d="M926.74,665.51c0,0.65-.9,1.18-2,1.18H848.31c-1.11,0-2-.53-2-1.17V649.25c0-.65.9-1.18,2-1.18h76.42c1.1,0,2,.53,2,1.18v16.26Z" style="fill: #cacaca"/>
                            <path d="M417.85,689.92c0,0.65-.9,1.18-2,1.18H386.62c-1.11,0-2-.53-2-1.18V670.83c0-.65.9-1.17,2-1.17h29.22c1.11,0,2,.53,2,1.17v19.09Z" style="fill: #cacaca"/>
                            <path d="M455.42,689.92c0,0.65-.9,1.18-2,1.18H424.19c-1.11,0-2-.53-2-1.18V670.83c0-.65.9-1.17,2-1.17h29.22c1.11,0,2,.53,2,1.17v19.09Z" style="fill: #cacaca"/>
                            <path d="M493,689.92c0,0.65-.9,1.18-2,1.18H461.76c-1.11,0-2-.53-2-1.18V670.83c0-.65.9-1.17,2-1.17H491c1.11,0,2,.53,2,1.17v19.09Z" style="fill: #cacaca"/>
                            <path d="M540.19,689.92c0,0.65-1.16,1.18-2.59,1.18H499.91c-1.43,0-2.59-.53-2.59-1.18V670.83c0-.65,1.16-1.17,2.59-1.17H537.6c1.43,0,2.59.52,2.59,1.17v19.09Z" style="fill: #cacaca"/>
                            <path d="M729.73,689.92c0,0.65-.9,1.17-2,1.17H546.54c-1.11,0-2-.53-2-1.18V670.83c0-.65.9-1.17,2-1.17H727.72c1.11,0,2,.52,2,1.17v19.09Z" style="fill: #cacaca"/>
                            <path d="M776,689.91c0,0.65-.9,1.18-2,1.18H735.11c-1.11,0-2-.53-2-1.17V670.83c0-.65.9-1.17,2-1.17H774c1.11,0,2,.53,2,1.18v19.08Z" style="fill: #cacaca"/>
                            <path d="M814,689.91c0,0.65-.9,1.18-2,1.18H782.56c-1.11,0-2-.53-2-1.17V670.83c0-.65.9-1.17,2-1.18H812c1.11,0,2,.53,2,1.18v19.09Z" style="fill: #cacaca"/>
                            <path d="M851.6,689.91c0,0.65-.9,1.18-2,1.18H820.85c-1.11,0-2-.52-2-1.18v-8.36c0-.65.9-1.18,2-1.18h28.74c1.11,0,2,.53,2,1.17v8.37Z" style="fill: #cacaca"/>
                            <path d="M889.17,689.91c0,0.65-.9,1.18-2,1.18H858.42c-1.11,0-2-.53-2-1.18v-8.37c0-.65.9-1.17,2-1.17h28.74c1.11,0,2,.53,2,1.17v8.37Z" style="fill: #cacaca"/>
                            <path d="M889.17,679.19c0,0.65-.9,1.18-2,1.18H858.42c-1.11,0-2-.53-2-1.18v-8.37c0-.65.9-1.18,2-1.18h28.74c1.11,0,2,.53,2,1.18v8.37Z" style="fill: #cacaca"/>
                            <path d="M926.74,689.91c0,0.65-.9,1.18-2,1.18H896c-1.11,0-2-.53-2-1.18v-8.37c0-.65.9-1.17,2-1.17h28.74c1.1,0,2,.53,2,1.18v8.37Z" style="fill: #cacaca"/>
                            <path d="M418.81,577.85c0,0.65-.9,1.18-2,1.18H386.62c-1.11,0-2-.53-2-1.18v-9.64c0-.65.9-1.18,2-1.18H416.8c1.11,0,2,.53,2,1.18v9.64Z" style="fill: #f0f0f0"/>
                            <path d="M457.91,577.85c0,0.65-.9,1.18-2,1.18H425.72c-1.11,0-2-.53-2-1.18v-9.64c0-.65.9-1.18,2-1.18H455.9c1.11,0,2,.53,2,1.18v9.64Z" style="fill: #f0f0f0"/>
                            <path d="M497,577.85c0,0.65-.9,1.18-2,1.18H464.82c-1.11,0-2-.53-2-1.18v-9.64c0-.65.9-1.18,2-1.18H495c1.11,0,2,.53,2,1.18v9.64Z" style="fill: #f0f0f0"/>
                            <path d="M536.11,577.85c0,0.65-.9,1.18-2,1.18H503.92c-1.11,0-2-.53-2-1.18v-9.64c0-.65.9-1.18,2-1.18H534.1c1.11,0,2,.53,2,1.18v9.64Z" style="fill: #f0f0f0"/>
                            <path d="M575.21,577.85c0,0.65-.9,1.18-2,1.18H543c-1.11,0-2-.53-2-1.18v-9.64c0-.65.9-1.18,2-1.18H573.2c1.11,0,2,.53,2,1.18v9.64Z" style="fill: #f0f0f0"/>
                            <path d="M614.31,577.85c0,0.65-.9,1.18-2,1.18H582.11c-1.11,0-2-.52-2-1.18v-9.64c0-.65.9-1.18,2-1.18H612.3c1.11,0,2,.53,2,1.18v9.64Z" style="fill: #f0f0f0"/>
                            <path d="M653.4,577.85c0,0.65-.9,1.18-2,1.18H621.22c-1.11,0-2-.52-2-1.18v-9.64c0-.65.9-1.18,2-1.18H651.4c1.11,0,2,.53,2,1.18v9.64Z" style="fill: #f0f0f0"/>
                            <path d="M692.51,577.85c0,0.65-.9,1.18-2,1.18H660.32c-1.11,0-2-.52-2-1.18v-9.64c0-.65.9-1.18,2-1.18H690.5c1.11,0,2,.53,2,1.18v9.64Z" style="fill: #f0f0f0"/>
                            <path d="M731.6,577.85c0,0.65-.9,1.18-2,1.18H699.42c-1.11,0-2-.53-2-1.18v-9.64c0-.65.9-1.18,2-1.18h30.18c1.11,0,2,.53,2,1.18v9.64Z" style="fill: #f0f0f0"/>
                            <path d="M770.71,577.85c0,0.65-.9,1.18-2,1.18H738.52c-1.11,0-2-.53-2-1.18v-9.64c0-.65.9-1.18,2-1.18H768.7c1.11,0,2,.53,2,1.18v9.64Z" style="fill: #f0f0f0"/>
                            <path d="M809.8,577.85c0,0.65-.9,1.18-2,1.18H777.61c-1.1,0-2-.53-2-1.18v-9.64c0-.65.9-1.18,2-1.18h30.18c1.11,0,2,.53,2,1.18v9.64Z" style="fill: #f0f0f0"/>
                            <path d="M848.9,577.85c0,0.65-.9,1.18-2,1.18H816.71c-1.11,0-2-.53-2-1.18v-9.64c0-.65.9-1.18,2-1.18h30.18c1.11,0,2,.53,2,1.18v9.64Z" style="fill: #f0f0f0"/>
                            <path d="M888,577.85c0,0.65-.9,1.18-2,1.18H855.81c-1.11,0-2-.53-2-1.18v-9.64c0-.65.9-1.18,2-1.18H886c1.11,0,2,.53,2,1.18v9.64Z" style="fill: #f0f0f0"/>
                            <path d="M927.1,577.85c0,0.65-.9,1.18-2,1.18H894.91c-1.1,0-2-.53-2-1.18v-9.64c0-.65.9-1.18,2-1.18h30.18c1.11,0,2,.53,2,1.18v9.64Z" style="fill: #f0f0f0"/>
                            <path d="M418.81,600.41c0,0.65-.9,1.18-2,1.18H386.62c-1.11,0-2-.53-2-1.17V582.74c0-.65.9-1.18,2-1.18H416.8c1.11,0,2,.53,2,1.18v17.67Z" style="fill: #f0f0f0"/>
                            <path d="M456.42,600.41c0,0.65-.9,1.18-2,1.18H424.24c-1.11,0-2-.52-2-1.18V582.73c0-.65.9-1.18,2-1.18h30.18c1.11,0,2,.53,2,1.18v17.68Z" style="fill: #f0f0f0"/>
                            <path d="M494,600.41c0,0.65-.9,1.18-2,1.18H461.85c-1.11,0-2-.52-2-1.18V582.73c0-.65.9-1.18,2-1.18H492c1.11,0,2,.53,2,1.18v17.68Z" style="fill: #f0f0f0"/>
                            <path d="M531.66,600.41c0,0.65-.9,1.18-2,1.18H499.46c-1.11,0-2-.52-2-1.18V582.73c0-.65.9-1.18,2-1.18h30.18c1.11,0,2,.53,2,1.18v17.68Z" style="fill: #f0f0f0"/>
                            <path d="M569.27,600.41c0,0.65-.9,1.18-2,1.18H537.08c-1.11,0-2-.53-2-1.18V582.73c0-.65.9-1.18,2-1.18h30.18c1.11,0,2,.53,2,1.18v17.68Z" style="fill: #f0f0f0"/>
                            <path d="M606.89,600.41c0,0.65-.9,1.18-2,1.18H574.7c-1.11,0-2-.53-2-1.18V582.73c0-.65.9-1.18,2-1.18h30.18c1.11,0,2,.53,2,1.18v17.68Z" style="fill: #f0f0f0"/>
                            <path d="M644.5,600.41c0,0.65-.9,1.18-2,1.18H612.31c-1.11,0-2-.53-2-1.18V582.73c0-.65.9-1.18,2-1.18H642.5c1.1,0,2,.53,2,1.18v17.68Z" style="fill: #f0f0f0"/>
                            <path d="M682.12,600.41c0,0.65-.9,1.18-2,1.18H649.93c-1.11,0-2-.53-2-1.18V582.73c0-.65.9-1.18,2-1.18h30.18c1.11,0,2,.53,2,1.18v17.68Z" style="fill: #f0f0f0"/>
                            <path d="M719.74,600.41c0,0.65-.9,1.18-2,1.18H687.55c-1.11,0-2-.53-2-1.18V582.73c0-.65.9-1.18,2-1.18h30.18c1.11,0,2,.53,2,1.18v17.68Z" style="fill: #f0f0f0"/>
                            <path d="M757.35,600.41c0,0.65-.9,1.18-2,1.18H725.17c-1.11,0-2-.53-2-1.18V582.73c0-.65.9-1.18,2-1.18h30.19c1.11,0,2,.53,2,1.18v17.68Z" style="fill: #f0f0f0"/>
                            <path d="M795,600.41c0,0.65-.9,1.18-2,1.18H762.78c-1.11,0-2-.53-2-1.18V582.73c0-.65.89-1.18,2-1.18H793c1.11,0,2,.53,2,1.18v17.68Z" style="fill: #f0f0f0"/>
                            <path d="M484.59,643.23c0,0.65-.9,1.18-2,1.18H452.4c-1.11,0-2-.53-2-1.18V625.56c0-.65.9-1.18,2-1.18h30.18c1.11,0,2,.53,2,1.18v17.68Z" style="fill: #f0f0f0"/>
                            <path d="M522.21,643.23c0,0.65-.9,1.18-2,1.18H490c-1.11,0-2-.53-2-1.18V625.56c0-.65.9-1.18,2-1.18H520.2c1.11,0,2,.53,2,1.18v17.68Z" style="fill: #f0f0f0"/>
                            <path d="M559.82,643.23c0,0.65-.9,1.18-2,1.18H527.63c-1.11,0-2-.53-2-1.18V625.56c0-.65.9-1.18,2-1.18h30.18c1.11,0,2,.53,2,1.18v17.67Z" style="fill: #f0f0f0"/>
                            <path d="M597.44,643.23c0,0.65-.9,1.18-2,1.18H565.25c-1.11,0-2-.53-2-1.18V625.56c0-.65.9-1.18,2-1.18h30.18c1.11,0,2,.53,2,1.18v17.67Z" style="fill: #f0f0f0"/>
                            <path d="M635.06,643.23c0,0.65-.9,1.18-2,1.18H602.87c-1.11,0-2-.53-2-1.18V625.56c0-.65.9-1.18,2-1.18H633c1.11,0,2,.53,2,1.18v17.67Z" style="fill: #f0f0f0"/>
                            <path d="M672.67,643.23c0,0.65-.9,1.18-2,1.18H640.48c-1.12,0-2-.53-2-1.18V625.56c0-.65.9-1.18,2-1.18h30.18c1.11,0,2,.53,2,1.18v17.67Z" style="fill: #f0f0f0"/>
                            <path d="M710.29,643.23c0,0.65-.9,1.18-2,1.18H678.1c-1.11,0-2-.53-2-1.18V625.56c0-.65.9-1.18,2-1.18h30.18c1.11,0,2,.53,2,1.18v17.67Z" style="fill: #f0f0f0"/>
                            <path d="M747.9,643.23c0,0.65-.9,1.18-2,1.18H715.71c-1.11,0-2-.53-2-1.18V625.56c0-.65.9-1.18,2-1.18h30.18c1.11,0,2,.53,2,1.18v17.67Z" style="fill: #f0f0f0"/>
                            <path d="M785.52,643.23c0,0.65-.9,1.18-2,1.18H753.33c-1.11,0-2-.53-2-1.18V625.56c0-.65.9-1.18,2-1.18h30.18c1.11,0,2,.53,2,1.18v17.68Z" style="fill: #f0f0f0"/>
                            <path d="M823.14,643.23c0,0.65-.9,1.18-2,1.18H790.95c-1.11,0-2-.53-2-1.18V625.55c0-.65.9-1.18,2-1.18h30.18c1.11,0,2,.53,2,1.18v17.68Z" style="fill: #f0f0f0"/>
                            <path d="M503.4,664.46c0,0.65-.9,1.18-2,1.18H471.21c-1.11,0-2-.53-2-1.18V646.79c0-.65.9-1.18,2-1.18h30.18c1.11,0,2,.52,2,1.18v17.68Z" style="fill: #f0f0f0"/>
                            <path d="M541,664.46c0,0.65-.9,1.18-2,1.18H508.82c-1.11,0-2-.53-2-1.18V646.79c0-.65.9-1.18,2-1.18H539c1.11,0,2,.52,2,1.18v17.68Z" style="fill: #f0f0f0"/>
                            <path d="M578.63,664.46c0,0.65-.9,1.18-2,1.18H546.44c-1.11,0-2-.53-2-1.18V646.79c0-.65.9-1.18,2-1.18h30.18c1.11,0,2,.52,2,1.17v17.68Z" style="fill: #f0f0f0"/>
                            <path d="M616.25,664.46c0,0.65-.9,1.18-2,1.18H584.06c-1.11,0-2-.53-2-1.18V646.79c0-.65.9-1.17,2-1.17h30.18c1.11,0,2,.52,2,1.17v17.68Z" style="fill: #f0f0f0"/>
                            <path d="M653.87,664.46c0,0.65-.9,1.18-2,1.18H621.67c-1.11,0-2-.53-2-1.18V646.79c0-.65.9-1.18,2-1.18h30.19c1.11,0,2,.53,2,1.18v17.68Z" style="fill: #f0f0f0"/>
                            <path d="M691.48,664.46c0,0.65-.9,1.18-2,1.18H659.29c-1.1,0-2-.53-2-1.18V646.79c0-.65.9-1.18,2-1.18h30.18c1.11,0,2,.53,2,1.18v17.68Z" style="fill: #f0f0f0"/>
                            <path d="M729.1,664.46c0,0.65-.9,1.18-2,1.18H696.91c-1.11,0-2-.53-2-1.18V646.79c0-.65.9-1.18,2-1.18h30.18c1.11,0,2,.53,2,1.18v17.68Z" style="fill: #f0f0f0"/>
                            <path d="M766.71,664.46c0,0.65-.9,1.18-2,1.18H734.53c-1.11,0-2-.53-2-1.18V646.79c0-.65.9-1.18,2-1.18H764.7c1.11,0,2,.53,2,1.18v17.68Z" style="fill: #f0f0f0"/>
                            <path d="M804.33,664.46c0,0.65-.9,1.18-2,1.17H772.14c-1.11,0-2-.53-2-1.18V646.79c0-.65.9-1.18,2-1.18h30.18c1.11,0,2,.53,2,1.18v17.68Z" style="fill: #f0f0f0"/>
                            <path d="M841.95,664.46c0,0.65-.9,1.17-2,1.17H809.76c-1.11,0-2-.53-2-1.18V646.79c0-.65.9-1.18,2-1.18h30.18c1.11,0,2,.53,2,1.18v17.68Z" style="fill: #f0f0f0"/>
                            <path d="M860.75,643.23c0,0.65-.9,1.18-2,1.18H828.56c-1.1,0-2-.52-2-1.18V625.55c0-.65.9-1.18,2-1.18h30.18c1.11,0,2,.53,2,1.18v17.68Z" style="fill: #f0f0f0"/>
                            <path d="M832.59,600.41c0,0.65-.9,1.18-2,1.18H800.4c-1.11,0-2-.53-2-1.18V582.73c0-.65.9-1.18,2-1.18h30.18c1.11,0,2,.53,2,1.18v17.68Z" style="fill: #f0f0f0"/>
                            <path d="M870.2,600.4c0,0.65-.9,1.18-2,1.18H838c-1.11,0-2-.53-2-1.18V582.73c0-.65.9-1.18,2-1.18H868.2c1.11,0,2,.53,2,1.18V600.4Z" style="fill: #f0f0f0"/>
                            <path d="M475,621.86c0,0.65-.9,1.18-2,1.18H442.82c-1.11,0-2-.53-2-1.17V604.19c0-.65.9-1.18,2-1.18H473c1.11,0,2,.53,2,1.18v17.68Z" style="fill: #f0f0f0"/>
                            <path d="M512.62,621.86c0,0.65-.9,1.18-2,1.18H480.43c-1.11,0-2-.53-2-1.18V604.19c0-.65.9-1.18,2-1.18h30.18c1.11,0,2,.53,2,1.18v17.68Z" style="fill: #f0f0f0"/>
                            <path d="M550.24,621.86c0,0.65-.9,1.18-2,1.18H518.05c-1.11,0-2-.53-2-1.18V604.19c0-.65.9-1.18,2-1.18h30.18c1.11,0,2,.53,2,1.18v17.68Z" style="fill: #f0f0f0"/>
                            <path d="M587.86,621.86c0,0.65-.9,1.18-2,1.18H555.67c-1.11,0-2-.53-2-1.18V604.19c0-.65.9-1.18,2-1.18h30.18c1.11,0,2,.53,2,1.18v17.68Z" style="fill: #f0f0f0"/>
                            <path d="M625.47,621.86c0,0.65-.9,1.18-2,1.18H593.28c-1.11,0-2-.53-2-1.18V604.19c0-.65.9-1.18,2-1.18h30.18c1.11,0,2,.53,2,1.18v17.68Z" style="fill: #f0f0f0"/>
                            <path d="M663.09,621.86c0,0.65-.9,1.18-2,1.18H630.9c-1.11,0-2-.53-2-1.18V604.19c0-.65.9-1.18,2-1.18h30.18c1.11,0,2,.53,2,1.18v17.68Z" style="fill: #f0f0f0"/>
                            <path d="M700.71,621.86c0,0.65-.9,1.18-2,1.18H668.51c-1.11,0-2-.53-2-1.18V604.18c0-.65.9-1.18,2-1.18H698.7c1.11,0,2,.53,2,1.18v17.68Z" style="fill: #f0f0f0"/>
                            <path d="M738.32,621.86c0,0.65-.9,1.18-2,1.18H706.13c-1.11,0-2-.53-2-1.18V604.18c0-.65.9-1.18,2-1.18h30.18c1.11,0,2,.53,2,1.18v17.68Z" style="fill: #f0f0f0"/>
                            <path d="M775.94,621.86c0,0.65-.9,1.18-2,1.18H743.75c-1.11,0-2-.53-2-1.18V604.18c0-.65.9-1.18,2-1.18h30.18c1.11,0,2,.53,2,1.18v17.68Z" style="fill: #f0f0f0"/>
                            <path d="M813.55,621.86c0,0.65-.9,1.18-2,1.18H781.37c-1.11,0-2-.53-2-1.18V604.18c0-.65.9-1.18,2-1.18h30.18c1.1,0,2,.53,2,1.18v17.68Z" style="fill: #f0f0f0"/>
                            <path d="M851.17,621.86c0,0.65-.9,1.18-2,1.18H819c-1.11,0-2-.53-2-1.18V604.18c0-.65.9-1.18,2-1.18h30.19c1.1,0,2,.53,2,1.18v17.68Z" style="fill: #f0f0f0"/>
                            <path d="M888.79,621.86c0,0.65-.9,1.18-2,1.18H856.6c-1.11,0-2-.53-2-1.18V604.18c0-.65.9-1.18,2-1.18h30.18c1.11,0,2,.53,2,1.18v17.68Z" style="fill: #f0f0f0"/>
                            <path d="M926.4,621.86c0,0.65-.9,1.17-2,1.17H894.21c-1.11,0-2-.53-2-1.18V604.18c0-.65.9-1.18,2-1.18h30.18c1.11,0,2,.53,2,1.18v17.68Z" style="fill: #f0f0f0"/>
                            <path d="M436.87,621.16c0,0.65-.9,1.17-2,1.17H386.62c-1.11,0-2-.52-2-1.17V604.89c0-.65.9-1.18,2-1.18h48.24c1.11,0,2,.52,2,1.18v16.27Z" style="fill: #f0f0f0"/>
                            <path d="M445.78,642.46c0,0.65-.9,1.18-2,1.18H386.62c-1.11,0-2-.53-2-1.18V626.33c0-.65.9-1.18,2-1.18h57.16c1.11,0,2,.53,2,1.18v16.13Z" style="fill: #f0f0f0"/>
                            <path d="M465,663.75c0,0.65-.9,1.18-2,1.18H386.62c-1.11,0-2-.53-2-1.18V647.5c0-.65.9-1.18,2-1.18H463c1.11,0,2,.53,2,1.18v16.26Z" style="fill: #f0f0f0"/>
                            <path d="M926.73,599.7c0,0.65-.9,1.18-2,1.18H876.48c-1.11,0-2-.53-2-1.18V583.43c0-.65.9-1.18,2-1.18h48.24c1.11,0,2,.53,2,1.18V599.7Z" style="fill: #f0f0f0"/>
                            <path d="M926.74,642.45c0,0.65-.9,1.18-2,1.18H867.57c-1.11,0-2-.53-2-1.18V626.33c0-.65.9-1.18,2-1.18h57.16c1.11,0,2,.53,2,1.18v16.13Z" style="fill: #f0f0f0"/>
                            <path d="M926.74,663.75c0,0.65-.9,1.18-2,1.18H848.31c-1.11,0-2-.53-2-1.18V647.49c0-.65.9-1.18,2-1.18h76.42c1.11,0,2,.52,2,1.18v16.26Z" style="fill: #f0f0f0"/>
                            <path d="M417.85,688.16c0,0.65-.9,1.18-2,1.18H386.62c-1.11,0-2-.53-2-1.18V669.07c0-.65.9-1.18,2-1.18h29.22c1.11,0,2,.53,2,1.18v19.09Z" style="fill: #f0f0f0"/>
                            <path d="M455.42,688.16c0,0.65-.9,1.18-2,1.18H424.19c-1.11,0-2-.53-2-1.18V669.07c0-.65.9-1.18,2-1.18h29.22c1.11,0,2,.53,2,1.18v19.09Z" style="fill: #f0f0f0"/>
                            <path d="M493,688.16c0,0.65-.9,1.18-2,1.18H461.76c-1.11,0-2-.53-2-1.18V669.07c0-.65.9-1.18,2-1.18H491c1.11,0,2,.53,2,1.18v19.09Z" style="fill: #f0f0f0"/>
                            <path d="M540.19,688.16c0,0.65-1.16,1.18-2.59,1.18H499.91c-1.43,0-2.59-.53-2.59-1.18V669.07c0-.65,1.16-1.18,2.59-1.18H537.6c1.43,0,2.59.53,2.59,1.17v19.09Z" style="fill: #f0f0f0"/>
                            <path d="M729.73,688.16c0,0.65-.9,1.18-2,1.17H546.54c-1.11,0-2-.53-2-1.18V669.07c0-.65.9-1.18,2-1.18H727.72c1.11,0,2,.53,2,1.17v19.09Z" style="fill: #f0f0f0"/>
                            <path d="M776,688.16c0,0.65-.9,1.17-2,1.17H735.11c-1.11,0-2-.52-2-1.17V669.07c0-.65.9-1.17,2-1.17H774c1.11,0,2,.53,2,1.17v19.09Z" style="fill: #f0f0f0"/>
                            <path d="M814,688.16c0,0.65-.9,1.17-2,1.17H782.56c-1.11,0-2-.52-2-1.17V669.07c0-.65.9-1.17,2-1.18H812c1.11,0,2,.53,2,1.18v19.09Z" style="fill: #f0f0f0"/>
                            <path d="M851.6,688.16c0,0.65-.9,1.17-2,1.17H820.85c-1.11,0-2-.52-2-1.17v-8.37c0-.65.9-1.18,2-1.18h28.74c1.11,0,2,.53,2,1.18v8.37Z" style="fill: #f0f0f0"/>
                            <path d="M889.17,688.16c0,0.65-.9,1.17-2,1.17H858.42c-1.11,0-2-.52-2-1.17v-8.37c0-.65.9-1.18,2-1.18h28.74c1.11,0,2,.53,2,1.18v8.37Z" style="fill: #f0f0f0"/>
                            <path d="M889.17,677.43c0,0.65-.9,1.18-2,1.18H858.42c-1.11,0-2-.53-2-1.18v-8.37c0-.65.9-1.18,2-1.18h28.74c1.11,0,2,.53,2,1.18v8.37Z" style="fill: #f0f0f0"/>
                            <path d="M926.74,688.16c0,0.65-.9,1.17-2,1.17H896c-1.11,0-2-.52-2-1.17v-8.37c0-.65.9-1.18,2-1.18h28.74c1.1,0,2,.53,2,1.18v8.37Z" style="fill: #f0f0f0"/>
                        </g>
                        <g>
                            <g>
                                <path d="M562.24,662.88s8.19-15.37,22-12.78-2.38,14.68-.31,31.29-0.43,24.69-2.12,27.5-40.66,35.28-43.69,39.51c-2.14,3-.1,3.39-0.1,3.39s-75.11,4.95-88.09-2.16c0,0,5.93-16.42,1.22-31s-9.6-33.47-8.88-36.1c0.26-.94.67-4.42,1.67-8.55,0.68-2.8-11.59-36.24-12.69-39.1-2.16-5.6,5.18-12.65,14.75-9.58,6.19,2,20.64,39,20.64,39s-5.16-54.29-.79-59.53c3-3.59,16.73-6.48,22.86-1.84s6,56.71,7.57,57.2c0,0,1.6-37.85,1.37-53.64-0.12-7.94,3.46-12.14,15.21-12,16.82,0.81,14.65,11.45,14.65,11.45,1.39,0.68-.65,48.08.85,48.86l6.55-43.71s0.36-11.69,16.43-10.76,16.76,9.79,14.94,16.75S562.29,661.18,562.24,662.88Z" style="fill: #f6e5d9"/>
                                <path d="M442.22,682.55c0.27-1-.82-4.94,1.7-9-1.42-6.23-15.82-40.92-12.72-42.79,0.49,3.31,9.46,34.65,18.3,42.28l1.28,10.62,9.79,38.8s-6.38,16.82-.39,21.06,58.4,6.4,77.9,4.83c-0.88,1.5-.53,3.18-0.1,3.39-8.72.69-75.92,4.5-88.09-2.16,0,0,5.93-16.42,1.22-31S441.5,685.18,442.22,682.55Z" style="fill: #ead1bf"/>
                                <g>
                                    <path d="M589.23,652.72s-3.5-1.65-6.15.45-5.49,10.7-5.49,10.7,0.47,1.7,8.61,2.34c0,0,2.2-5.52,2.62-6.81S590.58,655.52,589.23,652.72Z" style="fill: #f6efea"/>
                                    <path d="M583.2,654.78c-0.51,0-1,0-1.51,0a7.33,7.33,0,0,1,1.39-1.62c2.65-2.1,6.15-.45,6.15-0.45a5.91,5.91,0,0,1,.59,2.72A36.38,36.38,0,0,0,583.2,654.78Z" style="fill: #f9f9f9"/>
                                    <path d="M586.72,664.91l-0.52,1.3c-8.14-.64-8.61-2.34-8.61-2.34s0.18-.55.5-1.41A31.41,31.41,0,0,0,586.72,664.91Z" style="fill: #f6d1ca"/>
                                </g>
                                <g>
                                    <path d="M561.58,605.26s-10.89-2.48-21.15-.22L538,614.93s15.08,4,24,.75Z" style="fill: #f6efea"/>
                                    <path d="M550.75,606a35.5,35.5,0,0,0-11,1.57l0.63-2.56c10.27-2.26,21.15.22,21.15,0.22l0.12,2.6A34.9,34.9,0,0,0,550.75,606Z" style="fill: #f9f9f9"/>
                                    <path d="M550,615.6l12,0.08c-9,3.29-24-.75-24-0.75l0.19-.79Z" style="fill: #f6d1ca"/>
                                </g>
                                <g>
                                    <path d="M522.21,598.21s-11.24-1.88-21.1.94l-0.83,10s15.65,3.2,24-.56Z" style="fill: #f6efea"/>
                                    <path d="M511.56,599.58a33.7,33.7,0,0,0-10.66,2.16l0.22-2.59c9.86-2.81,21.1-.94,21.1-0.94l0.53,2.58A36.37,36.37,0,0,0,511.56,599.58Z" style="fill: #f9f9f9"/>
                                    <path d="M512.34,609.15l12-.58c-8.39,3.76-24,.56-24,0.56l0.06-.79Z" style="fill: #f6d1ca"/>
                                </g>
                                <g>
                                    <path d="M486.57,605.82s-9.16-1.53-17.2.76l-0.68,8.14s12.76,2.61,19.6-.46Z" style="fill: #f6efea"/>
                                    <path d="M477.88,606.93a27.48,27.48,0,0,0-8.69,1.76l0.18-2.11c8-2.29,17.2-.76,17.2-0.76l0.43,2.1A29.63,29.63,0,0,0,477.88,606.93Z" style="fill: #f9f9f9"/>
                                    <path d="M478.53,614.73l9.77-.47c-6.84,3.07-19.6.46-19.6,0.46l0.05-.64Z" style="fill: #f6d1ca"/>
                                </g>
                                <g>
                                    <path d="M445.66,627.84s-7.5-.35-13.12,2.16l1.64,6.36s10.58,0.86,15.05-2.14Z" style="fill: #f6efea"/>
                                    <path d="M439.23,629.49a18.37,18.37,0,0,0-6.26,2.15L432.54,630c5.62-2.51,13.12-2.16,13.12-2.16l0.89,1.59A24.23,24.23,0,0,0,439.23,629.49Z" style="fill: #f9f9f9"/>
                                    <path d="M441.79,635.47l7.44-1.25c-4.48,3-15.05,2.14-15.05,2.14l-0.13-.51Z" style="fill: #f6d1ca"/>
                                </g>
                                <path d="M581,649.8s-10-1.21-18.75,13.07c0,0-2.39,22.64,3.23,32.25,0,0-1.45-23,.22-31C565.7,664.17,572.88,650.71,581,649.8Z" style="fill: #ead1bf"/>
                                <path d="M536.77,605.77s-7,51.63-4.09,54.7l-5.23.89S534.1,608.5,536.77,605.77Z" style="fill: #ead1bf"/>
                                <path d="M498.44,600.83s0.07,56.57,3,59.65l-5.22.89S495.77,603.56,498.44,600.83Z" style="fill: #ead1bf"/>
                                <path d="M465.22,606.19s-0.53,40.75,5.63,65.16l-4.18,1.72S457.94,622.36,465.22,606.19Z" style="fill: #ead1bf"/>
                            </g>
                            <rect x="444.41" y="749.33" width="100.16" height="18.67" style="fill: #f1f1f1"/>
                            <rect x="532.11" y="749.33" width="12.46" height="18.67" style="fill: #e5e5e5"/>
                            <rect x="441.08" y="755.13" width="108.7" height="29.9" style="fill: #2789c0"/>
                            <rect x="536.77" y="755.13" width="13" height="29.9" style="fill: #004e82"/>
                        </g>
                        <g>
                            <g>
                                <path d="M742.66,654.65s-8.19-15.37-22-12.78,2.38,14.68.31,31.29,0.43,24.69,2.12,27.5,40.66,35.28,43.69,39.51c2.14,3,.1,3.39.1,3.39S842,748.51,855,741.4c0,0-5.93-16.42-1.22-31s9.6-33.47,8.87-36.1c-0.26-.94-0.67-4.42-1.67-8.55-0.68-2.8,1.88-36.16,1.85-39.1-0.1-8.26-5.18-12.65-14.75-9.58-6.19,2-9.79,39-9.79,39s5.16-54.29.79-59.53c-3-3.58-16.74-6.48-22.86-1.84s-6,56.71-7.57,57.2c0,0-1.6-37.85-1.37-53.64,0.12-7.94-3.45-12.15-15.21-12-16.82.81-14.65,11.45-14.65,11.45-1.39.68,0.65,48.08-.85,48.86l-6.55-43.71s-0.35-11.69-16.42-10.76-16.76,9.79-14.94,16.75S742.61,652.95,742.66,654.65Z" style="fill: #f6e5d9"/>
                                <path d="M862.68,674.32c-0.27-1,.82-4.94-1.69-9,1.42-6.22,3.61-43,.5-44.86-0.49,3.31,2.75,36.72-6.08,44.36l-1.28,10.62-9.79,38.81s6.38,16.82.39,21.06-58.4,6.4-77.9,4.83c0.89,1.5.53,3.18,0.1,3.39,8.73,0.69,75.92,4.5,88.09-2.16,0,0-5.93-16.42-1.22-31S863.4,677,862.68,674.32Z" style="fill: #ead1bf"/>
                                <g>
                                    <path d="M715.67,644.49s3.5-1.65,6.15.45,5.49,10.7,5.49,10.7-0.47,1.7-8.61,2.34c0,0-2.2-5.52-2.63-6.81S714.32,647.29,715.67,644.49Z" style="fill: #f6efea"/>
                                    <path d="M721.7,646.55c0.51,0,1,0,1.51,0a7.51,7.51,0,0,0-1.38-1.62c-2.65-2.1-6.15-.45-6.15-0.45a5.83,5.83,0,0,0-.59,2.72A36.18,36.18,0,0,1,721.7,646.55Z" style="fill: #f9f9f9"/>
                                    <path d="M718.18,656.68l0.52,1.3c8.14-.64,8.61-2.34,8.61-2.34s-0.19-.55-0.5-1.41A31.37,31.37,0,0,1,718.18,656.68Z" style="fill: #f6d1ca"/>
                                </g>
                                <g>
                                    <path d="M743.32,597s10.89-2.48,21.16-.22l2.41,9.89s-15.07,4-24,.75Z" style="fill: #f6efea"/>
                                    <path d="M754.15,597.8a35.54,35.54,0,0,1,11,1.57l-0.63-2.56c-10.27-2.26-21.16.22-21.16,0.22l-0.11,2.6A34.93,34.93,0,0,1,754.15,597.8Z" style="fill: #f9f9f9"/>
                                    <path d="M754.89,607.37l-12,.08c9,3.29,24-.75,24-0.75l-0.19-.79Z" style="fill: #f6d1ca"/>
                                </g>
                                <g>
                                    <path d="M782.69,590s11.24-1.88,21.1.94l0.83,10s-15.66,3.2-24-.57Z" style="fill: #f6efea"/>
                                    <path d="M793.34,591.35A33.74,33.74,0,0,1,804,593.51l-0.21-2.59c-9.87-2.81-21.1-.94-21.1-0.94l-0.53,2.58A36.36,36.36,0,0,1,793.34,591.35Z" style="fill: #f9f9f9"/>
                                    <path d="M792.55,600.92l-12-.58c8.39,3.76,24,.57,24,0.57l-0.06-.79Z" style="fill: #f6d1ca"/>
                                </g>
                                <g>
                                    <path d="M818.33,597.59s9.16-1.53,17.2.76l0.67,8.14s-12.76,2.61-19.6-.46Z" style="fill: #f6efea"/>
                                    <path d="M827,598.71a27.46,27.46,0,0,1,8.69,1.76l-0.17-2.11c-8-2.29-17.2-.76-17.2-0.76l-0.43,2.1A29.68,29.68,0,0,1,827,598.71Z" style="fill: #f9f9f9"/>
                                    <path d="M826.37,606.51L816.6,606c6.84,3.07,19.6.46,19.6,0.46l-0.05-.64Z" style="fill: #f6d1ca"/>
                                </g>
                                <g>
                                    <path d="M848.77,619.71a30.28,30.28,0,0,1,11.54.49l0.48,5.46s-8.55,1.77-13.15-.29Z" style="fill: #f6efea"/>
                                    <path d="M854.6,620.45a18.5,18.5,0,0,1,5.84,1.17l-0.12-1.41a30.28,30.28,0,0,0-11.54-.49l-0.28,1.41A19.83,19.83,0,0,1,854.6,620.45Z" style="fill: #f9f9f9"/>
                                    <path d="M854.2,625.68l-6.55-.3c4.6,2.05,13.15.29,13.15,0.29l0-.44Z" style="fill: #f6d1ca"/>
                                </g>
                                <path d="M723.91,641.57s10-1.21,18.74,13.07c0,0,2.39,22.64-3.23,32.25,0,0,1.46-23-.22-31C739.21,655.94,732,642.48,723.91,641.57Z" style="fill: #ead1bf"/>
                                <path d="M768.13,597.54s7,51.63,4.09,54.7l5.23,0.89S770.8,600.27,768.13,597.54Z" style="fill: #ead1bf"/>
                                <path d="M806.46,592.6s-0.07,56.57-3,59.65l5.22,0.89S809.13,595.33,806.46,592.6Z" style="fill: #ead1bf"/>
                                <path d="M839.68,598s0.53,40.75-5.63,65.16l4.18,1.72S847,614.13,839.68,598Z" style="fill: #ead1bf"/>
                            </g>
                            <rect x="760.59" y="740.81" width="100.16" height="18.67" style="fill: #f1f1f1"/>
                            <rect x="848.3" y="740.81" width="12.46" height="18.67" style="fill: #e5e5e5"/>
                            <rect x="757.26" y="746.61" width="108.7" height="29.9" style="fill: #2789c0"/>
                            <rect x="852.95" y="746.61" width="13" height="29.9" style="fill: #004e82"/>
                        </g>
                    </g>
                </g>
            </g>
        </g>
        <g id="Fusée">
            <g>
                <image width="85" height="129" transform="translate(643.16 154.49) scale(0.48)" xlink:href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAFgAAACECAYAAAAUaexgAAAACXBIWXMAABcRAAAXEQHKJvM/AAAgAElEQVR4Xu2d93sd5bW2z79yTpJzEggQegstAYMh9N7BQDABQi+BQAiBQAiEADYY914k2bK6ZPXee++9t+/YKlsS55rvXmu9o71lDNuAaQk/rGtmb21JM/c877PWeqfs//A87z9+iK8vwn7g3yEOffBj79AHP/IOrfqJd2j1/3iHPiRW/3fw9Sq37j4X7u+FRtgP/KvGQQG6+icG86OfEsd5h9Yc7x36+AS3/Ll7zy1X/9RCYAP64FGCDvuBf7VQFX4IpDU/AyIg1wJ07YneoXUneYfWn8LyF7YUwOtkyeuP+dlHP7f4ENgf/kxBHw3ksBv0rxKqVoG6TsABdD3QNgBww6neoY2neYc2ncny9MXl1AaW63l//ekGeh2fW3tyELZAPgolh92w73scWvXjINiNqHEjsDYBa/MZLE/zpjaf5U1t/aXFlnN5fY43tYn3NvN6E683sr7egE8p7NNCIP9UvfnzIIfdwO9rHHz/v8wK1mEDGwGyBahbUeWWM7ypbUDcejZLAQvEnRd5Uzsu5PUFvD6f5a8I3ttyvoHefJ6DfbaDzN9awyhYc4IlwX83wAdFtWsBu5khvR2lbkd9O4C6ndgJtB3nBaHuvsSb2nUxr4kdv2Z5KZ+72EJAb7kwuBTgG/kb688wuxDAHx3/uSoOu7Hft1DVrmfHt6G0XcDYhfJ2n2+xB1C7iT2XGNjIK7ypiMtZB+oui+ndl3vTu5Yb6B3LvOkdlwF7GZCBv/UiU7TYxQb+/scnGmD8+F8esFqC2MFWhu8uhnLE+RaRgIkC5l6ARQEuCqCRy73pfVd703uv8qajiMgrWV7Dkoggdl8BZEDv5v1dV1gIaIG8BRvZxN/feKZVGx+5kg6rOBLksBv+fYiDUiGsZyd34K8RKGwfKo0GajRQo4G6H6XuB1Y0MPfJEoj7r2d5Ha+vJW4ANut7bwQ070fyXiSvI4hdv7HYKUoWFQN4yy8V8NSG06ysU8DWjBy+bWE3/rsehz7+mXntHnZ6Lz4Zw3COBUYsUOOuJIAZB7AYFBsLyBgAxt7M8ibiFkCzHs36/lsBzfrem2wZxTLqhhDQqFj92SVAV20cWneyNSdSUaDgw1Ucdge+q6GJzFdtJFawH3Ul/Mabigds4jWsAzYRQImoMoFlAjDjAZdwO8vbiDsAz3rsbd5M7F3eTMwd3sx+1vfz/r5bvZl9t+lSgQvkPah/12VAXuaqjfOsnJPaWbu/41TF/xKAD35EabQF5ew+21Qbx04nX+1NJaHSFGAmEynASQZqEpEMtKTbvZmkeywS7/ZmEoh4wMYR8StY3gto3osR2Cz33+nNRAM9+rYgZDx6aodUGyh4m5Rw4sXSjJxsgKXl5sCHbmvYnfkuhSYyUe02EtkeqoME/DUZG0i9zps6AIBUQBxApWkATUWdB4jUe4BNJAPtwP3eTMp93kwykUQkSvzWIoGfxQE6FtBxvB97j4GOvt1ZBtYSwQHcjf3swCa2o+JtomJGEA2LttwCmComdJvD7tR3JRTuBoHLzkSca5aQSKZPR63p2ED6bS7uJO4mgJoGrLQVQGaZ+gCAAXlgJfEQkFlPeRjQvE7idSLLBAHNMp5l/AMGOkaUfKslwL0CmSS5Z7mpeDsq3iI2Ia30Cd9fBSvcjezADlrWvexUEj6bwo5moqwMIhPFZgA2E7CZKzRmMoCTjirTAZUByHSJRwD+iAE+8Dtv9sDvgczrZAH9OyA/5M0m8zqR9YQHgewrWaziZqs0pKTbLfXyxa77O9cULHMbHx+ngEN9OOzOfdtxUBqHTRT0OymL9jEsk4GbylDNRlVZRDZDOBuw2fcSAM0CaBYKzHzQIgt4WYDMJDKI9N97s+lPEE96s2lPKmSNlEdZ8n7KY95skgOe8IDzZlQcc3sQcCRlWwQVxc4LDLC04Bt+YfMd3yfAWt9uRhm7GYb7UUsKcNMpubJRUy47nItqcwGbi9JygZmz0iIbhWY/apEDxGwii8iU5dPebMZTrD/L8hlA8zqN12lPG+ADjwP5cafklebN8ag4DshS0kndHEXJRjc4LV3h9nOtBd8ss23fI8Bahm1GFXvI1DHsSAqqycQDc6gK8lFsngRg81BZHorNQ3F5KC8XMLmPAxZIeQDMJXIkngM0kSXLF1j+AcjPA5llOu9lsJ7+rIEWFSc7fxbAkgyl4oi9BSVLnXxVEPBOmTCSRHeyzX8cNi8Rdke/jTi46keUYcCNQBlxJLMDwM0iyeSRxApIXgUM2wKgFqDaAiAUoNR8CSwg/0lAo9RcVJkPvDzA5QE0l8iReAnAfwTwi7YUwJksM3md8YLBFsipYhcCmf+RTCSIiin1Ym60jjCKmngP27b7AgMsChaLWP0dBywbd3AdySKSoRdPu5uK5+UwNPOxhCISWNF93nQhqi3CBgpRbdFjLFFswRMsAVPwjEUh0AqBWUDkE3lE7kteIO/PXiD3T8QrXiDnT0DmveyXvUAWP88S0C84JQM4Vfz5Yas4EgEcD+DYG4F8/SLg6QiqiZ3iwzQcG040wCRlf3/C7vA3GbJhCjeKYZe4zODmYQmFVAkl9xPsaAmKLWGnS1BsCWotfgrIqLUYKEWorxDFFgOu6GXiFV67KABswWteIP8vBMs8lrmvEm6Z/YqCVsAZzzpvfsxBllKOUZOID8ezPTH4cDQ+HHkxkGXK8zwD7Cv4uwhYS7Gt+FiUNBAoNw24WSil6C5vugywpQzTUna0DLClqLb0aeIZIKPWUoZ5CWCKGealf2H9z8SrvAZc0V8sCoFa9CbLNwD9VyC/DmQBznre6w7yy2YdWS9YEpRqg7JOAUuDIoATaafjbrC5jb2Ua3uwiF0IYvuZNk36XQR8cM1PzXMjzzG46XhcFiVRCYmslJq2gh2sAGw5VlCOFZQDtRyllkkApIyhXcoQL2WolwOrDGglwCthvZj1YqCWvM3y70B+C8h/IwQ26/n8LP9NB/nPahuB7BcNcCYqThcVS83MQU4m0SXcioo58DEIYB82Efkrm3Peec530yIOfkSdu+WkINwM4GazA6UkszJUU4XPVpK8KrGDSuygEhuoBECFBFArUF05FlAGnApAlf/Nouwti1Kglr5rgEveIf5hUSiwZcn7BX9zin7V/DnnRas2pKyTujmNBkQ6wRSZy0DB8TegYpmhwyaiZBIfBcsEv6/gkG4uLICvMxbr3EhKsQQ6owyGXQ7Dr5zatoLyqJqSqxrVVj2hgGerUWzVSy6AWokVVGIFFa8BGUCVf7eoeNvFP4EN3PL3vbmy9yxK31PAc8XvLkagiN8peMP8OU+S3x+JF1zNjILTUXAqBzvlbgBTqiUggDiEsF8m7inXZGJfLEI8mMboOwFY61zp0CIc3Ezg5lICVbAjlQzHWlRbC9galFuLmmrZ4RqsoAawNUCtxmurAVuFBVQBpxo1VkkArFLifQU8V7HKovwDAEussigBeilRwmeL/7EUMtXGbA4HM4vkmfF7A5wmcxkATkbBiSg4XuaZsYkYbCJK5iXO+O4A1qtqZG4h4iyFO50F3DzgVopq8dt6wNYDtg4F1QO2HrB17HQdUOuAWvs6AYwaLKEaG6h5z6Ja4gMCgFVEpSw/YvkhkCVYL2dZzrJstQH2IQtg8eUCRkI+Ks590TUnjJwMEl3GyiDgJEq1RHJE7OVUEyh4n5wsPVsBC9xvFbCWYgr3TAcXJeTfBFgUUkNt24jPNgC3gUTW8EeD20DZ1fBXi3og1OGZdQCpxQZqUF8dUGslVivguRogVgOxei2AP3bBeiXLCpYVslwTAtl5dLEkPwAX4sXUzoFcBzgTBWdQxaQCOIUklyQKxiLiaYD2AzjqwkUFK+BvK8ktzoqJcmMvJJlda4CLUUU1tlCH5zZRfjWyY40ot4kE1ojPNqDcRna+EbU2ALaBZFUP2Ho8th6Y9cCsW2NR+7GLDYBeT7CsZlm1DsBE1QZb+pDLV5k3kwDnBHIRgKVmzn8RwFQS2bTcWQ9jEw9gE/ca4BQEkQDguMsNsJwDVMDHewe/rSpiEa4kNOBOZbKBOQAuoTuqRR31NA/NzxJ4XzNwm/HaZsA2YQlNwG1i55tQWhPe2oRSG1BeI5AagNSAKuvXWdQBs5ao22xRuwnIRPVGgtfVrFetd5AFMCouc0mwVCqNN52CASytds5jFhn3AZkq4gBJLhkFJ2Jr8QCOEw+mFt55lin42wCscDcBd+dpNBIAziA55OJhRWxsHd7WgHJbUG0LO9SCaltIYi3AbUZNLai1GbU2o9ZmgbvKADei2kbANgKrEWgNGyzqAdmwjeUWYiuQiVrWazZ787Ws12xxoDeYbag3YyvlJEQp6Urw9mJq6EJpq1GwzGtkYRGZJN806uDU20IAU0Xsv9jOCYoHr/+2AMs5tB2neof2Uutm4Ft5lDnFDLV68VwaiBaSWSvKbQVu6ysGuBW4rVhCK6ptAW4LcFuA2wyQFsA0A7IZsM2bDXAjywbgNWz15ht3ePMNEtu9+XqibhvB69ptGgLbAIttfOSqDACXcyBLUXDxXwxwAQc9lyoiB8DZD6JiFJwmFnE9PgzgBOrg6F9jEVQRW+VCwhO+ecAHP6TW3X6KwU1kY/JvMLjVKKKBJqIVuG0otw24bcBto0Joo/RqA24bVUEbYFsB28pQbgVsC1BaANQCzGYJVNkMtCZANu/y5pt2A3gncF3USwjs3bbuIM/Xbnb+LAmQg1aJRZTjwwK4RNprusJCAOdhD9krCTw4/Q4UfDOArwPwVagYsUTLlUIyZXnqN28RWutuO9k7tI9WMg7fTcOzCm40uI14bhtw2/HbduC2A7edKqGdIdoO3HaqgnbAtn1IoLI24LZhB60otw2orUBt3Q5owLYAr1kiwqLJRWOEgW2MZLknCFkUrbaxwVUaH1pZJ4DLpfPDIopRcBEHPh/AeZRpOb/FJqgi0rGIA1hE0pVBi4g4z85yi0VIHfxNANZad+svvKloHy4bUyjl2AoqBfHcxw1wB3A7qBTa8dwO4Hawg+0M1Q58toMd7wBAO2DbgdGGFbQDtW0HsRPAwGrdY9ECzNYolkSzH3sBzbJpr4MsgHc529gCZA5WDSOiRko6UbE0JtJiY08ldHOFlIr5WEQurXL2vQY4DQUfQMHJzoNj5Dq3c+zkwNrjvhnAmtSkBd5ykje1n+GTSqYtcnDrqRiaHwUoG98J3E6U28mQ7KRS6ARuB3A7PyLI8J3sfCdgOwDRwZBuR7kdgG0HUjuw2oHaFukiGsD7AOxHtAFuluW+IOTG3ebP9eLLm6ziqOUgSnNSSQst8xllVBEycVT8PD5MmZaL/+ZQRWRgEenYWyoKTqG8jF3mTct1GXLxi1iEAP4m6mAFrHDP86YOXIrnctSrqSHraCZaUUQHcLuB24Vyu4Db9ZbB7QRuN2C7ANvFjncBthOwnQznDoB0otQOCUB1oMz2vS5iALzfBeutRAvrLW7ZvD8EsljHLpcAUbGUdXX8v1qxiXeBzLaUUweXouDiZ7GJJw1wLh6cSUmZzr6kigfjv3GXWgUhZ7sFMMn84Nd9XcQi3BiByxHOZiiV3mKA2x4zuJ34bg/dWTdwu7GFburPLqqFLsqlHna2G9V2o64uwHbhtV0orguonX4AqgNgHaizHXgdcSxjCZZtEqy3xnoLrfEAjnWQo802mvYEAVPOzTdsAvJaA1wtgGVG7hUH+Glsgm3OFwXfQ7mGgjMAnHa9AY6/zADLhTBYhNrD13nplE2a47ux/NMUvCmTjSiTioHypp2h1gncLsqxXmyhB7g9qLaHOreHMqwbuL3rDXAPcHsA27ML0PhtF8O6G6jdQO0CVBfAOmNcJABYIt5bYLnQLsF6e6K30MZ6W3yImvn9Zg5QE4AbBTAKbiS0QaFKqcGDq94Csswpk+SKnwQwdlbwUBBwOvZw4BoDnLDcLEIuhpFLZ9f89OsD7MM9tAc/SpbZMWrE8tsMbiNlTpfYAlm5jxq3lx3oZSj2otoeSrEe/K8XO+jFDnrx2d4dBlcDxfUApgdI3aixG1BdLLtQaicgu5K9hc4kiw6JRIPbnhwCmc+2CmQOUosD3ESCbBIFbwCwtNh0czVvo+I3AIxFlP0BFdNoFNIm51NB5ApgxJJxkwKeTpA2WU560jhtP90u6fr4p0v895gB1gkcuUBkN16UxD/NAG4FflVN1q1/IAi3H9X2AbcPuH3YQh/K7RXlUov2odo+LKFvmwHuBULvXhdA7Y11gIHVjSq7AdedYtHlolNCgB8AdLKFwhbIsQ6yVBoctGYAN2M9NCjz0mrXUQfXkuRq/oaKKdPKX6CSQMHFjywFLApOwfYSrzDAe87RJKcJTjz4WANWuFLv7jwVuBTdGVLrXmdwGwTuU8BFCb142gAb3g/cfuD200D0odx+4PYDth+wfYDtA2wfAPqiDG4fYHqB2gvUXqygB2A9KLUHiN0uulx0uuhKc5BTHOR4A6yVRpSVdC38n2axiPUAXuMA/x0Fy8T9n7xAxYsoGA8uxiIKJcmxP1m3BBVMgtMODsByVb3CPey6tGMG+NCOU+jS+GdplGM5dDjVdyncmVaOfo/ARQ2DbPgApdgAcAdoIvrxvAGBi+8OYAv91Lf9qKofAP0CFhh9QO0Dal+ixkIvYHsB15tKpAM5JLolANudAeD0EMjJzjbigCxVBn+7NcLVzlgE7fZ8I4DrsYg6LKLmryiYJFchFvE4gLGIgvtR8QoDLApOvlL9V6+m33mmtsiq4NXH+Ap3hUunNpVwkQXqVbj1dGrNDxncPpQwROs7BNxBgYstDAJ3ELgDJJdBwA5Q2w6QyAbwxwEA9AO3H8X1A7df4AK2D1B9gO0DXB8Qe130+JEJXIksB1kAp5plCGAqjQXKuYW2fVY3t2IPtNvzTShYJo7qsYfaN1EwNXAlCa7iOXz4CQNcyEjMu5tmQyzieuyBURqDPUT+Uj1YActU5WH28JUAqzXI5aSS1ES9eK/Crb6TLg24vcDtf9GbHSBhDAN3CLhDlEFDlENDKGYQ5Q5iCYOodhBFDaLcAXZ+AJUNAHcgiQBOP8O8H1D9Ajbd4PZlWfT6kW2Ae2SZZZBVxanOmwWyVBkAbt9H8L/oBA3wOgBzwBuoIOqoIGpeQ8FydvopFEzNXkyCLqTJyLsDmyCvZNDqJ1NBxF5iCU78V1rkI/jvMQB8vMKdzuSIFlEb1gC46bcGVwHju8PUlcPAHQbu8BqDOwTcISqGIXxwiKE6xA4PAncQuIP47QBJaRAwAwzxAcAOAGsAsP0SOQQg+/zgda9ErgOcHaLmNOfPUmXwNztRMbXzgtTQ7dJib8UiZLoT/63HHmqpIGoQRBWWVoH/loUAzkc42VhEKiXaAZlsX+ZN7TpLmwydRVvz6QriSwNWuOuP8w7tO2cR8CLcdpJC33MoF7gjKHfkHYUbGP7AAA/TRAyzY8NYwjA7OcxwHcIWhoA7hHIHUdoQUAaBMwjYQaAOAGsAVQ4AbwCQ/RJ5Fn25LljvzXOgs8w21JNTDHAXf7eT5qNzP4AjQgCvRcVsW8M7KBj/rUa9lXRw5VQQZY9SSfzOABeQ5LJvVsDTSZfbpbRYhFwQrnAP6+C+NGCFq5c3naVVw7RUDWUc2dq7DbAPdxjfHaViGMHbRtiBEXxuBM8d2ewAC1yUO4zfDgN2COUOobKhNBcAGgLsYJYL4A7mAxiIA/kW/Raf9Bd4n/TlO8i5pugesYw0V2kkG+AuASxdICOnjQTXuhHAVDKNjK56yrPavxjgKvy3nARXiv8WU0EU3uMUDOD06yzB7QVwxLneoY0nfqZ6vzRg9V0tyehkSm9ycKUkewJbYOMG/2RwR4E7SnYexXdHqDVHqBZG6KBGUNAIOzqCakdiDfAwcIdR2zCqHXZwhwA7BKxBoA0BcbCQYDngot8P3u/zIeeGeHIIYK2bsYhOPLhDJooEME1G84coGItowCLqqHSqn0fBqLf8MQf4fgOMB89ksa8ZkuSWW4KTEu1YAl6S2ES9xTeGwKUV7mfjVL1s6Bg15SiJYxSFjFIxjG5UwPOjkUvhjlCKjZDlR0hII0AZBuqwWwrcIYGLSoeKLAZDYkCi2EIh5zvI4smZrpQDcI8ATjTItNoLnWIRlGctawDM6GpECA1UELWv4MF/cICxuhJGZNG9pt4cRmnm9ea/CZcaYDz40KaTjg1ghUsrqDVvMnCzrjDAdZQvnY8Z3EGBSzMxhhrGGHZjbPwYyh2lSxtFMaMMzVFsYRRbGI0JgQuEEdQ2AtQR1DcCoGHADgNrGGUOFzvAxS5KAFzsoiQEsqg4z5KfApZSjr/bw8iQBoU2e0EnjXYa4NaPgSwWwfY24L+1L4Yo2AEuXoH/3mX2kCm3iEkHx+iNOs87tP00nZY9eIQW+UsB1rmGvZQmyb+mW7sWuPdQkj2ogAMDbNgwrfC4wP2ng/uRAR5jZ8YAPLY3CHeU4TqKskaBOwqEUQd2BLAjQBpBjSNAHZYocVEK3FIDrFEG4FILhcxn1ZNzXYXhAPcCuJf/1YMHd0ehYAB3UKK1UaI1I4RG1Fv/ZwBTPVST4CrYn3KxB5fcRL1ZiEnuDUlcvlgD6yT75mOgYFXv5hNtrkHg5lOqSGKrx5vaHwEuw2roZQU8N042HgfuOHDHSWpj9Ppj+O4YSW2M8mgMuGPAHSOzj6Y4uIAdBcqogV0YKTC4GqUWwyEhYIfKLQZ9yAIYmxhwgPsdYG1MxCb4n934b1cEgGky2mkwWj80wE3YWQPbXveSA/x7KgjKs5L7Tb0+4DSZZP+1qldP08sU5cc/+0y4Rw9448/1lPtUCnBz8aDiGxxcjnI3w2kQwMOvenMT74bARbnjZOlxfHccxYxHK9yFMXxwDDWNsdNjeOQoQ3nMwR0FzmiRxQjARlDpSFkwhiXKXVSEQC51VlHkEmAukLOtblbAomCqiB4BzIHuZDR1sG1tAG5htDXRYNS/DGAsrorurZIKopzyrBTAeTQX2SQ3ufkm4TIAX2y3kkmLvOWUz+zgjhrwYlkmlzo5wDMNGH8bG9D1mMEdoTgfxcMmSBYTeNqEwEUh4wzDcdQyTlIZp/4cR0XjeOE4OzxGUhsDwBhgx1DtGGDGCh1g4I4CbBR4I6FRYWA1KoFb4dTsFDzoFDyQQ2QBOdN1gDKHgT307EXFVBCdjKp26t9WxNCMpTW+joJf8QI1qLcKwVTgv6Uk7qJ7DHAOgNOuNsBxF1t7LKfp159gp4i+7BNPFhPb9pOBe7ElNinLHODAIJ41woaNvubgssETaxTw/AQKmUAp4yS2CXZuHAWNs6PjKHecnR4X5aKy8XwDOwbYMSCNCViAjVYEY6RyaQxXGeBFFZe5xFdkZdxgngGmQflEusD+ZAcY/+1mNHVSnrV/BGDKsxbsoRH/rUe91bTHldhD+UosggRXKPZAcsu4zpKbwJUGwwcs6j3sHNwXAyxzvHKG4gBwM+Ws8LUGt5XE1s0wGjLAQbhs9ASJYwKFTOC7E3u8BeDOT2ANEyh34sBSwOPAGAfuuA8XsGPAGgPaGABHJaqCMRISSwCXWnWhdTIHjLrZAGe4uQxsqQ/AvQKYg97FyOqggmgDcDMNRhP2VsdIrKE9rpIEx/6V3GeAc2WK8loDLDflLAI+leT2s8/s4MIC1jneLSdq1TCdztAoILFV3OrNtnBkOx91cElsoySHSQBP+oDXO8AMxYlIBbwwwQ5OJBvgCRQ1Tjk2DoQJB3ccOOMocNyHW7U0lgCuXgpYwyl4yKl3EIug+/tkMNPmMxQwFtXL9vRw4LtQcAfb2ob/NrP9Dai39hkULP77sCrYyrM7DXDqVdoeT++/yMozvcjk+E+doj9qwItzDTKJnrYM371SE9tsM77UQdXQ+5TCnVO47xrcSTZ4EvVOopAJsYWII8OdYNhO5BlcBSxwUeA4oMYFriyBOBYSo37UWCjkage53Eo4rY8BPOQULIAH8PkBbKlf1Mv29O4AsJxARQTtq7AI/Lfl9RDAjMqKlabeIur7vFupHm4wwHEuuYl6tznAH312efa5gP/3vf/0DsrFelLzpl7iTeddBVwyavtDWANDaOQlgzv+pgPMxk4y5CY3GuBJUS8JZTLOWQPDdAJbmGDITmQ7wCh3AigTpQZWAVca3HEgjoWED3a0NgSybxVOwdqMFBpgOsBPhvg/gwKYA9wf7QDjv93U5J10cO208C0k5uZXFfBcHS1+DYArH1oKWPxX7jJNWOZNRV9od/tvCl+eHRVghZtxmTdTeqM328Q/7WD4DNPtjLBBo68uqnd+kg2eRBWTeNskCpmMMLiTwJ301Zvp4OYuhTsBnAkBXBWE64cCrnVR5wDXhqi4wqoLrY/5e8MhgGUmbkCmPOMNcN8u1It1dSGELgH8rqm3iRxST5NUKwmOxF2OBZZgD/m3od7rrXpIpDXe758ectXDZ8z/hgWscKXujaQsOyDqvXopYB8u6p2ffJ/4yMHdHAKXenMy3gFmJyfTnDXkOLAlIXCBNFHpAAvY2qUhYENjtC5EwZWufCt1HZ+01YyO4VynXv5/Pwm2n+TWtxvACKCbCqeD7W5j9LUwChtpLuqfNfVWPewAk8gLbjfAYg8+4IhzTMEbPn+CJyzgQ1tPYlhcYufXSm/2ZhtXaFMR6H/aAI+9puqdX7QGksYkDcXkTmBGhsBFuZPp3ieT+OGkKBcAk6GAHdwJYE2gyIlQuHXBGKsPAezbRJUr4coM8IhTsAAeyjTAg/jvAP7bTzXTi3V1I4QumouOd1Aw1UML+9H4AhYhCn7S7KEMKyy+x2pfqR7kPukkknzMRTb3IJPrHx6dej8FeNF7o86iLKE0y7vGm21Y4QU6qBq6n/Dmhl506n3Lm/9/Ani1U/AG9d4FvNfUm+TgpgGUnZ3EGibzDO5kiC0o4BC4E6Fg6y3GQsMHXLot/z8AABobSURBVO1KuHIHWDo+6f6kxRYF8z+HGDkyeT/A9vRHOMAk4S5E0U7n1vq6RSP7JAquRkAVlGelUp7d4c3k2eyZwpX2WOZ+BbBMT34lwFQP00nAzXbqbXpAASvcYfxq9HUS2D+ID5x6zXsXJnc59SaY706mAjPDwUW9k6LeEgM8GWINCljg1lkcDni8IQxgp94R1CsTRMPY0HB6CGC2qQ/r6nHq7fynA4w9NDEam8gp9YzMmkcNsNiD+G821UMa9pC83KqHPVQPcoHJxpOOeIlUWMAKV7q2zSca4IzfeLN1WEM9Cu552psbZGNGUO8Y3jv+jgGe+BiQ2xxcfG5y/xLfDQLOc3ABOwmUSR+uKLcmCHeiPgSsr+AGb6lFhNiDAB49HDB2NCxnRNiOQbZnQPx3mwHuZrR10Lm1odzmP6k9BOopz2rp3qpo/culPb4TBUt7fKM3k371ImCFK9WDeO9hF1kfFWBt+db+zJuKPMebTrucI0hpVgvc5t85wHjV8J8N7jhJYuJDbSoW8N4g4DhnD756nfdOFgaVq4CBO+lbQwhcP3zl+rEEsg+40uCOhtpDtlMvI0hOPw2yTf27HWCxhw8cYMqzllcMcN0TBhgF+4DVHuRG9JTLrf6N+qU+L0jVe5TJ7YgKlruAphOXKeDZolu82ep7vUDTw95c7/Pe3MCfvPkh7GHsbQC/R3xIN7aRQMHaEse4xiIReAccYN8aSl2UG1gF7Ptu/WHhg20MAezDlaoixB5Gy44AmJEzlGTqHaQW7yfx9lHh9GBnHW87uH9WewjUU5rVUtdXI6IKqocyRmyxtMcy/3BNSPVwrgN89NXDEQFP7TqTgvpi/vhVDBnU2/CQN9dOcut+zpvrf9mbH8YeRvDfMRLFGIDHNhjgcZLIGDszEa9d2ycTouDMIGCpexfVW2VwJ1Hi5GFgF+EeCXC9A+zbQ5lTsMy8CVznvXJeT9XL9gyIeinNelFvN9vc+XZQvU0vGOA6AFdRPZTfb3Dzb1EFq3pl7kGaC7n2YbM99OiLJLhFwKre9T/3pnaeoUNiJvs6ShbUW7/Sm+t8lqP/R29+4FUAv0Gg4JH3vIXhj7yFEQCPkeBG97hANWNxQEgCFjs7gUXohI40FlKalZn3KuDaEMANS+L/FG5jEPIi3GoDPFYRVK9ObxY6wIwcPTPNaBqU6mE74QB3SmlG7dtGadYi/vu8wZXqoZL2uPReA6zVg5RnV1CauVND0hpvOPrm4siAkb9MJs9Q983m3OAFyu6mfPmdA/yiN9/3ijff/xdsAsBD77ITq4C8DsibWWdHRiMc4HgApBAAHmfIynSkzJjJbNliYxHSVCwB3KjhA/6/RcDOexUwB2gsxB4ULiNlJMMAD5PchvaZen24PZSTXQ6wVg9URA0kt7rHFfBsGaVZyV00F7dpclO4tMYKWE4N7Twj7MnN8IDxmOmYi7VzmWWYBPiHgZqVdDwA7gZwjwPc9wYb/g924ANiDTuDDw9sQjEkuhF2bAQfHsGHRw/YkB3JNHWN+ZM60hZXOlBV3mI7LKWZwFXATSEqDgXs1DvmqgdVb679j+FUBzfWAWZ7+jYBmMqhC1vr+JtT70sA/oPBrRH1PugA381+32qVwwF/alImd85SwAfFHr4sYJm4kCMk17vOUlwHyKSBygc4yo96881PsnF/YCNfYmNJcn1vUrS/DWQA9+PDfZRqfUAe3GkZW4bmEDYxjBcPouShNFc65VopJWAUUqVTpD/f4GpfV44tqlfjcMCh9uAAjwhgkttQNNuAXQ1QOfSS2HqodrreNcCteG8z6m1EvfUC+BFvtuIBg1twq9a+06miXvHeC6z29e1BAH9BuEHAesvVqd5MwnI97x8ouAOLWOHNNz5mgNsFMEmuExV3vW6Ae1BxH4B7sApKoIXeja4kwir6Im2KcDBZJ1w+GZLhm+3mCYrctGKRF5xQd1ORI/6UpJvUUeifBdiduxvNdvbA/xmOd4DFHjYb4G7gdtJYtFHDt7xs6hW4tY8uVa/YgzzGJvWKxZkzndzZ5rq3L1D7fgqwWsTmU7yZ6Iu92dRrUPA93hw9+XytKPhpb771eRSAgjupgztIdl3YRDeAu/5JoOQuEl7XBp2tUsA9e+z8V+9+AzyAigeBMJitJyP1pKSe2nEXkMgZidCzFQrZzQGP+Gc2/HkHlDsWol4FnKYjZmF4v1kV3rvQJ40FXVsndW/76yHqpS2up/atWmnqLb3bGgt5jE3qb7RM1dIs8tzF6uGLNhdHBDy16xx9sMRsytVeIPd2b64UwBTf841PePNNDnIb1UQrfowa5jvedG0n0fGBniFY6GbHuiR22enxbjnJuN9OmeslqBl2tU0fQ7o/x05QLl6lU2xnh0NPCel0pD8l6de7rmOTmnc0x9nDAYM7FGmAB7YGAXe8gXr/YuptfsHginoVMKVZqUzs0BZnXmOARb3yGEeZOdt+mnfwcy5NPZpYBCzPnZne+ysvkHmzF8gBcMl93nzlQ948pcw8GzXf+JQ33wLk5ucNcAsJr+UNnVeVk4fzbdSZbWu9hXasopOqonO3XkWz0M2Q7Y51V9YkuSttSH592Xr9gl4oItczyFU5ctpdTr8L6MWzFWWmdn++d1ja4UxX86Y6701w6uWgDkhptgHvZZu63jbA7a85e3iO2v6JYHID7mzhbQ4wpVmaP7HuzrtJ5bD26E4NhQU8teNsAF+kgOfy7vTmK6ggKgBMGzlPxp1vAHA9ftzwHIpGyY1YRstfib8T7+op8Pm2Nayv1asWFzq260V2C51yJQ2Qu+LsAmi5M0gu+dfLmvyLp7P0kqdP+nLt+rJ+/+K+PHchiTsNP5Rrfq6J84AlUureT4bjggomuS30rV0KWP2Xzq3hSU1sqt5yp968my25pYXYg3Ru/t3zX0G9i4Dl4cJT287QR6MEMm40wKUPePMl9zvATsUKmrKtkaRXB+h62ucmIDdQXTT9Qy+km29CyU1r9MLmhTYgtzFk29nx1ii9fF8v45fL+eWy/m53FbosezL1stNP9GLqLFO4XmOWHrw6R84QD9DEDKW62TL+zmC0zTkoXFHvRuC+75IblUM79tAqpdnzQcDVDxlcqRxkUkfswQeMes17T7bK4VgAlj8iD7ecib3UC6Td4M3l3uHNFd3rzZf91pRc/Qh+DGj69vlaVFyLJ9cCuPYFAsh1rwEdwPUS7FwDhX3jx3YHj9wN37rbbptqYQi3Arktxu786XS3WSnodLu3QkFnmcrl4mm5MlLspZfok/Nr8S4EbGywJRblDpBk+9cb4CXqfckLND7pOrffWXIrc4Bz5aKSK23eIeaipaXZV4QbBPz+f+kXKc2IB6deZ4AL7kbB9wUhVz2MJxPVJL5KAf6UAa7BKmrx47o3lwJucIDlPrTGbXbjX/MevRFwEXJrjLszM8Fgy40rqmj/9qwku+y0h5/3xNvFI30xdvq9b4+dZ5P53oGdVjmI9/byv3t9wH9FvbTFzX5p5uyhjLa46A6zB0ozA7zMZs12nRl8NMGxAqxJTqqIPed5gRTKtCzxYSAX3mPJTiAraDy53Lx5rvJxb67iKeI54gW9O3KuCquopSWtxf/qVusdlPP1QK5dF4Qs9wo3A0Vua22yRw4stOzXW15V1XKzisBvi7YbVjr2WpLUamSfu3hkl17fIOfYFnrpIvtRb/+mINxu4HZKcntV7UETW92jZg2i3uI7rbHIlTlf4CZd+unG4hjAPQLgX3qB5Ku9uYybvLnsW725/DsNcvF9i6Dn8OW5cgCX/94AlxJlfyCoMcupNSuoOatJfNV4YM0HQGenq2lXa9a6m693uJuxd7oHZ0TqTdoLLQBtJVpkXayEaEOl7RK7LWl27iC26uVPC90sezZZkyMlWe8qK8tEuV3Uvh2vm/+2vIg9yKyZzPn+ztRLY6H2QO2rgOWU0N7z7ILqL3jWOFwsAj608WQgn+sFkq4CMIlOqomc24B8l0HGk+eKVzjYgC4S2A8DGCWXPMPyeSBTCpW9qo8EmKt8B7jvAVzuYH/fgUbRNai5fqs+cUSfPtK4x1Qtj4JRdcv6DrvNVW6zkhtV2oh2WQKyQ67KAWoXftu9wc4S93AA6ShtzkF8989WmrX+kcYCuPWPKdxA5W/Ve2eLbjd7SHfWEFL3fpk537CAJWSuc3rn2d5s4m8McLoku9ut6aCqmCvwQQO5CMiFKLkIJRez8YWouUggv2SAi1Fy+Zu8JouXvU3Igy7e1yfwzVfjzdXrDbBC3u6er7PdPcNhs/l20xYD3ExV0LLR7qdokcudiHa7cEQvINHzbP/QMxXStS0Cpiyba8G6mkLUWy5Tknhv/s06JTudstyblids+5M6x6g0OzJgCuqp7Wd5s/HL1SY02WXdgh/fooADkvjyLPnN5QI8/x4vUPCgF8hbSZA88gFd8Czg2alCQBcBuoQkU/qWAS4XNa9GyWv0EYfzVeuCkOXxLnWbTd11wKwHZsN6S5Jyo2ATKm0EaBMW0CJNDeutQG19R09gLp6Gl9my1ldc5fBisHLQSZ3fmj04wFqWiffG/iqY3NQejk1y+xRgmamXWngm8gIvkHC5eXH6jdTFN9HZ3eYF8GRZKuRcAS5xP+/fx/tAziWJ5LFD+c8pYHk04VwxgEv+ps8jU8j+E1DlaXsVKK8KcNUW9mAisRGihqhlyNdJ4OV1AKx/20rBRoA2o9TmN12jI10anWXbGzbXK5PpzS9azSvKpWpQa5AJdT3fdrN1bvIYXbGHGDfvsP3LnRIKF4sr2s1tPU1jNmaZFxCrOHCtN5t2vbXPEqJoH3Y29pF9F7GC91ByDirOJVvnPaNPzAvk0JbmkfiKSDbF2EUJkEuBLI+WLX3PnoSqoFG1PH5WnlsmT0uVBxNVSfzdnt9QI3f/yD1sHKx6uZfiNbvcX67plWgiml+x6xuaX9ZTQTqhoycyaYmrHnRwnTX4cJOXf7b/vvc1AJaQ74GYklk1aZnjRcVXebNADuDHGnizQs5E1Rks0wQ8VpGJijNQc8ZDrKPkTEBnPw1kuqdcvLAAKIUAKkRlxUArfkcfyDlX+o4pW23kLX2k1lzZm/pgInm0y1z1mwa4Gog1QKxl6Ne+rPdSyAXTc/Vy0QhA66li6hk59eQBOc/mT+hQlgV0xuweBSwnEmbSfbiXmv9K9SDlGbWvXtCH0MJB+yKx5MXB1f/tTW8/05uJON8LxF6mKp4VyKkOsqhZQ9ZvBP71BJDT71TAs6krFPBsOsrJwPsy2dnsP9gDj/XhxwAqAHQRMIsAV4wyS95yKucgFKPMEj5TCswyhno5MCuk9ANmJTCrAVsNzBoqlloXdbJ8mniS9x+3C0jkLHHlg9a1ldxj05F+U+EDFrjR5wfhuut9//frBCxxaMNJ5sP7L/ECccu9mYQrgHw18K4jBCiNiFhHEu+l8DrlJn5+K0uK9wMr9HHcgXR2MgMVZT3jAL/A8o/2FQvyGG/9NgBZvqpPOp0rJIpeseqjhCgFbsnzFqXPBQFXveAA8141aq2mBq+iTKyWFliS2e8XL+AL6Fniu/UyqFk5kSlzDu5KHT0ddHhbDOBjDfeIgOWi4hmphwE8E3eZPj5wVpV8tQWAZc5Y30tiPeHaIOAUvC6JnUpdqU/vD6SjqEysIvNZffC8hjwjXSAL4FzA5xH5RIEEB6RQHqWFfxei/mIJDlQpCav0Mb373eJRu9Wq4hEDLJf9V/1eL96Ty58CZdhV6Qq9QlLOsylggSun4n1rELg7TrMJdVc5fDOAV/3Em9pCotv7K538mcGLJWZ9u5CQ16LshCtZF9ioOJEdib+N5V0cBBJL6sP6PRQB/VImIGUALgtPzkLR2cDMktdPm1fnPmPJUQDnSyUCwPxHtL4OFKLIIoZ8EcvilRYlLkpX6v1sATpLuWklQAuv6pUrJAvvMsBylWTmde42gOXBK9UPa4u/DrhHBCwxJTax+5emYoHsQCtkWeLPs9jHbNwV/Ow3BNDjyM6x8nT+W/gMwzKZ0ijlIf26mtkDjyroQIao+Rmzj/THnE8/YpEFwGxAZq+0qiSP9TxgFfA6H0UWkEhpbgKFLIseIFgvluA1bXyALjNQfK+e7pJ7K2aL7tKL+GblHjfgzshNLImX2al4gSvXmcmjuL4ma/hcwPJV5Zrs9pznzVCyaSjoy2y53723jwOwn/f2Azn6at4TyDcDG+XEYxVJKCnpQYMs36iSSgJMI1IfcjZCpK/U56MHMlfqM3oD8pTTLEBlEzlUKDl3o3DKwVyW2tzca8tCgbnCAMt6obx3t97XNpvDQXZ3xstJXAUstwHITYT+VZICeO3Xk9jCApaYlnJt5znedOSFALzExTJbRl9sEYWN7BPQly8BPOMDTlhhgJNQczIAk1lPvt9CAKfyfhqRymfT8e+0O/URsrOZqC+Dv5HF62wii3Wpu3PusAYnD+A0PIECoOaznn+nxmy+PPZFVMtBzpTHb11JDllu9xfrHZruVNC20752awgLWI6sqFimMAWmPKdcoQpg8WdqZQUc9WvKOt6PRMn7UEo0fhcD5Ng79EvuFHLifU7NRALwEgGaLMHPU4BygEi5RUs+BZx2qwFO53WGwLpFn1k2Sw0+6zrKgJsnkZBn6czmCFh+nkn5mH693lesT4eKv8yebxZ1vj0l1b8FgGT+dcP9fMCrf+JNS2enKr5AvytCoe4DaNSFWsrNRBB7LvSmd/HzPaJorGIfOxaNeqIZojFAiQNown0KeSZOEiGRIMmQSJDkeANBuZd8owFOuc7q69QbrCyk7p6lBp+lyZmlbZ+lozTQBjsIlp9l8Lm06+y5Oklsi8CNucSebyZwtxpcfzryWwUsId9RKd9wMk3CE8ByUlSaEPVmQt/fSeziZ7tRdiRJLwoV72Mn916/CHkmRr6vmPX9gI/hZ7HX6/cByTeqyNclzCRcrU/119o6WcrAa60UdK36EsgCUgDLuiz9dfm5/1zJxCu0xFyEK99xv+10OrXj7OrIVT/+RuB6YQEzjHR+YufZpmIBK1B3n+vg8v62s7zpHbzeIUpGxRE0JxF4X9S1gBYl3+iAi31cY4BjWMZK8LlYPi/VSDyKS7xSYzbpKgOcco1B9pscAe0vfejyM7eUZ/pqWalwl9n3WwhcVe5JBpiR+U3BlfjcH+q5uk0nq4rVKgSsLOUUv5yFZsOnt7LcLq/52XY5COzcLiqNCIBFXWm2EQnEqMvNo/fys31EtCTMSx3gywwMtbUG5aA8wntGau5QyLLuv6bpkZ/r5+TAyN+QykZ+X+Dqd1vI+bXT9Hyjwf16K4YjRdgP6DwxGzm14yxTrCzFNnzAW073pjazvkUgn8/PfwXgZfrdw6bmy+37LyN4L0L8G5XvlUTJejTLmEuDJaBAkvbch62gr9LHeStIQhodfd8/GPLZ/cvUvuTCGQm5xkMEoYA3/kK/a/PrLsc+K8J+QDxLVSxAdzrlCuCtp+vM29Rm4G8+PQh4+4WqYP3uYVHzTl7vvkC/OVC+nlG+f02GrlYikjClMvHr7BgHOn75UiWHAo8LORCEnxs0sDGFih1orD/RrOEbqhiOFGE/oOfryLxTagenL8YUypjaeJI3teEX+sXNU5uxkc2oe9t5Bnm7wBZLOc9i9/nq4XqJFrW1AgHwtKup5UuXrIHx1eyUHBvy2le581eFKyFfNyZf+bjlVBWDwl13glqC2Ny3BVci7Ack/HniabEKUa0omp2YQiFTclXQetY3GuTprUDdik9vlXU/AZ5lZ60lMe75pUGOujA4rPFLAS3fC7SoZr/mVj/9tYVawEXB32epUDe72HSKqXbtz7/xZPZZEfYDEvLgCfEyBStLH66AX/dzA7zhFAf5DDz7TLMOUfu2M4OAd7nqQwBRQ6uSFfSvnJovCYLcZxaiP4+0mCLJ+l/vKD6rQEWtAtdZwTdZgh1NhP2AhAw12QEFu8GpVr6c7uPjDfJaX8Wnml1sOkUvxTLAp1uClMrDV7Eq2beLC4KQdbhfEFS3fMaFVjLbz9K/pYlLPfYE3Qarb+Xuy+8WXImwH5Cwu5AcWNkx+YpxdkobEYEsy/X+ATjJVC6QxVJIigoHMFrqqYrP1e/BVHiuvlbYi+AvCH5Oft/9DR3+AnXdCWYD8kgX91Ci7xpYP8J+wA/9WnEp2WTnxDJCQiGrF58YBCxevdUBlqS4CPlsi10GWZc7TJmqUFXqmfr7fvUiB8r81eCqFXwLNe2XibAf8EN92EFWsOykH1NrnVU4hatXC2ASkIYADlHiImQJ+ZnGaQZSVKqXjf508aZrvxII9wit72KE/YAfssOH1hwXBCv1sXyNma9ksQ3xZVHxxpMNsnqxA+0A+kC1nAoNZzlaWq36ySLMb7vM+qoR9gN+6CO+HFxNeh+6kC+dFjiibLEP8WhJQn7VoWp29akMe1lXLz3ROiw31P04+P6PjumFH992hP2AH6IqX7n6fcgK+X/svTWmPgUsPuk6qMVsr/ELp9LjF0up0Aj3/7+vEfYDfuhwleG7+r/dV9v+JATwzxSc2cQJZhUu0/vQpeUOqvT7Pey/SIT9gB/qi/q14j/5DMDHOcjHm0qlhBJPlQMjIb+z+vOfkvevGGE/4MciJE0+PzbYouZQyALVz/7ujMG/kp9+mQj7AT8ElILVzP4jU7JvGeLLi2WVg8974f7mv0OE/YAfi0PdB70qCNL3ZVXsB5/+Pp9/5wj7AT8UrB8fhCjYPd7Vt5Bwf+ffLcJ+wA/fT5d68Y9+8NkwEfYDfph6f+R8OATu96x1/aYj7AckFtXrK9it/7vUsl8lwn5AItQefrCELxZhPyCxRLk/WMIXirAfkFicLvxBuV84wn4g1H/DffaH+HSE/cAPcL9ahP3AD5XCV4uwH/ghvlqE/cAP8dXi/wNQogHIMMmesQAAAABJRU5ErkJggg=="/>
                <path d="M637.23,141.69c10.85-7.27,18.6-2.75,29.17-.88-2.52-8.8,34.28-47.62-3.7-39.44-14.11,3-33.9,20.82-39.44,41.79A53.14,53.14,0,0,0,622,165.77C624.22,157.7,628.31,147.66,637.23,141.69Z" style="fill: url(#linear-gradient)"/>
                <path d="M716.3,177.89c-0.12-12.45-7.25-16.13-14.84-23.14,8.78-3.09,20.19-53.37,35-19.68,5.52,12.52,2,37.79-12.39,54a56.58,56.58,0,0,1-18.16,13.86C711.42,196.63,716.4,188.11,716.3,177.89Z" style="fill: url(#linear-gradient-2)"/>
                <path d="M683.46,174.85a210.07,210.07,0,0,0,36.95-37.91c33.29-43.67,43.5-88.49,35.53-123.69-34,12.82-67,47.81-85.17,99A198.6,198.6,0,0,0,659.65,163Z" style="fill: #d0cfde"/>
                <polygon points="658.51 152.18 658.64 152.8 692.78 169.5 693.38 169.24 658.51 152.18" style="fill: #5b5a5a"/>
                <path d="M731.77,57.43a119.11,119.11,0,0,0,23.32,8.69c4.33-18.94,4.46-36.9.85-52.87-15.59,5.88-31,16.43-44.83,31.07A116.49,116.49,0,0,0,731.77,57.43Z" style="fill: #23232e"/>
                <path d="M714.6,40.74A97,97,0,0,0,734,53.43a99.43,99.43,0,0,0,22.15,7.9c3.32-17.17,3.15-33.46-.16-48.08C741.65,18.64,727.52,28,714.6,40.74Z" style="fill: url(#linear-gradient-3)"/>
                <path d="M659.32,153.06l-0.07,0a102.48,102.48,0,0,0,.28,10.25l3.69,1.81c0.17-3.12.48-6.33,0.93-9.62Z" style="fill: #fff;opacity: 0.1"/>
                <path d="M668.13,141.85c2.43-8.22,5.4-16.76,8.89-25.44,20-49.8,49.17-85,77.89-102l0.27-.3-0.08-.34c-34.64,14-67.07,47.87-85.21,99.08A215.83,215.83,0,0,0,662.4,139Z" style="fill: #fff;opacity: 0.1"/>
                <path d="M733.65,82.47a15.31,15.31,0,0,1-19.95,5.11,13,13,0,0,1-4.52-18.67,15.31,15.31,0,0,1,19.95-5.11A13,13,0,0,1,733.65,82.47Z" style="opacity: 0.1"/>
                <g>
                    <path d="M733.86,82.54a15.31,15.31,0,0,1-19.95,5.11A13,13,0,0,1,709.4,69a15.31,15.31,0,0,1,19.95-5.11A13,13,0,0,1,733.86,82.54Z" style="fill: #861935"/>
                    <path d="M730.63,80.74A11.26,11.26,0,0,1,716,84.51a9.52,9.52,0,0,1-3.32-13.73A11.26,11.26,0,0,1,727.31,67,9.52,9.52,0,0,1,730.63,80.74Z" style="fill: #d3ecf8;opacity: 0.2"/>
                    <path d="M730.11,80.46A10.62,10.62,0,0,1,716.28,84a9,9,0,0,1-3.13-12.94A10.62,10.62,0,0,1,727,67.51,9,9,0,0,1,730.11,80.46Z" style="fill: #191928"/>
                    <path d="M712.09,73.26a9.08,9.08,0,0,0-.39,4.17,3.73,3.73,0,0,1,.67-0.24l18.78-4.82a8.85,8.85,0,0,0-2.23-3.43Z" style="fill: #d3ecf8;opacity: 0.1"/>
                    <path d="M730.54,79.72a9.64,9.64,0,0,0,.58-1.3l-16.65,4.27a9.38,9.38,0,0,0,1.11.87Z" style="fill: #d3ecf8;opacity: 0.1"/>
                </g>
                <g>
                    <g>
                        <path d="M659.36,150.42a102.78,102.78,0,0,0,.21,12.74l23.89,11.68a112.24,112.24,0,0,0,10.9-7.3Z" style="fill: #cccbcb"/>
                        <path d="M675.17,162.17c5.42,2.65,10.58,5.39,15.38,8.13,1.28-.89,2.54-1.79,3.81-2.77l-35-17.12c-0.08,1.56-.1,3.07-0.1,4.58C664.4,157.11,669.74,159.51,675.17,162.17Z" style="opacity: 0.1"/>
                    </g>
                    <g>
                        <path d="M693.17,169.32l-34.62-16.93-1.43-6.7c0.17-1.16,1.28-1.63,2.47-1L699.12,164c1.19,0.58,1.44,1.72.57,2.53Z" style="fill: #cccbcb"/>
                        <path d="M676.86,159a136.58,136.58,0,0,1-19.35-11.43l1,4.85,34.62,16.93,4.71-2A138.82,138.82,0,0,1,676.86,159Z" style="opacity: 0.1"/>
                        <g style="opacity: 0.5">
                            <path d="M675.91,160.4l-0.22-.11a0.37,0.37,0,0,1-.15-0.49,0.41,0.41,0,0,1,.5-0.17h0l0.19,0.15a0.35,0.35,0,0,1,.16.46A0.38,0.38,0,0,1,675.91,160.4Zm2.18,1a0.32,0.32,0,0,1-.18-0.43,0.36,0.36,0,0,1,.46-0.16l0.21,0.07h0c0.37,0.05.26,0.32,0.18,0.48a0.35,0.35,0,0,1-.46.13l-0.22-.09h0Zm-4.54-2.22h0l-0.22-.1a0.36,0.36,0,0,1-.15-0.48,0.4,0.4,0,0,1,.49-0.16h0l0.19,0.15a0.34,0.34,0,0,1,.17.45A0.37,0.37,0,0,1,673.54,159.21Zm6.92,3.39a0.33,0.33,0,0,1-.18-0.43,0.35,0.35,0,0,1,.47-0.13l0.22,0.1a0.32,0.32,0,0,1,.18.44,0.35,0.35,0,0,1-.47.12l-0.21-.11h0Zm-9.3-4.55h0l-0.21-.11a0.33,0.33,0,0,1-.17-0.44,0.35,0.35,0,0,1,.48-0.12l0.21,0.11a0.33,0.33,0,0,1,.17.44A0.36,0.36,0,0,1,671.16,158Zm11.68,5.71a0.34,0.34,0,0,1-.17-0.45,0.38,0.38,0,0,1,.49-0.16l0.23,0.07h0a0.35,0.35,0,0,1,.16.46,0.38,0.38,0,0,1-.48.15l-0.23-.08h0Zm-14.06-6.88h0l-0.2-.13a0.33,0.33,0,0,1-.16-0.45,0.36,0.36,0,0,1,.48-0.12l0.21,0.11a0.34,0.34,0,0,1,.16.46A0.38,0.38,0,0,1,668.78,156.88Zm16.44,8a0.36,0.36,0,0,1-.16-0.47,0.37,0.37,0,0,1,.48-0.15l0.22,0.09a0.33,0.33,0,0,1,.19.43,0.38,0.38,0,0,1-.49.16l-0.23-.07h0Zm-18.71-9.41h0l-0.25,0a0.3,0.3,0,0,1-.18-0.41,0.34,0.34,0,0,1,.47-0.09l0.21,0.12a0.28,0.28,0,0,1,.2.38A0.31,0.31,0,0,1,666.51,155.51Zm21.2,10.37a0.3,0.3,0,0,1-.2-0.39,0.31,0.31,0,0,1,.44-0.09l0.19,0.15h0a0.28,0.28,0,1,1-.24.48l-0.19-.16h0Zm-23.58-11.53h0l-0.23-.08a0.31,0.31,0,0,1-.17-0.43,0.35,0.35,0,0,1,.47-0.1l0.21,0.12a0.3,0.3,0,0,1,.18.41A0.33,0.33,0,0,1,664.13,154.35Zm26,12.69a0.33,0.33,0,0,1-.18-0.42,0.35,0.35,0,0,1,.47-0.14l0.22,0.1a0.33,0.33,0,0,1,.19.43,0.35,0.35,0,0,1-.46.13l-0.22-.1h0Zm-28.33-13.86h0l-0.21-.11a0.32,0.32,0,0,1-.16-0.45,0.36,0.36,0,0,1,.48-0.11l0.21,0.11a0.33,0.33,0,0,1,.15.45A0.36,0.36,0,0,1,661.75,153.18Zm30.75,14.94a0.33,0.33,0,0,1-.18-0.42,0.35,0.35,0,0,1,.46-0.14l0.22,0.1a0.33,0.33,0,0,1,.2.43,0.35,0.35,0,0,1-.47.14l-0.22-.1h0Zm-33.08-16.2h0l-0.21-.12a0.32,0.32,0,0,1-.15-0.45,0.37,0.37,0,0,1,.48-0.1l0.21,0.11a0.32,0.32,0,0,1,.15.44A0.36,0.36,0,0,1,659.42,151.92Z" style="fill: #676767"/>
                        </g>
                    </g>
                </g>
                <path d="M659.79,189.57s28.62-82.7,41.15-76.53C713,119,659.79,189.57,659.79,189.57Z" style="fill: url(#linear-gradient-4)"/>
            </g>
        </g>
    </g>
</svg>
</div>
<script src="../js/main.js"></script>
